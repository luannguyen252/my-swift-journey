//
//  Weather.swift
//  WeatherAppSwiftUI
//
//  Created by Mohammad Azam on 3/8/21.
//

import Foundation

struct WeatherResponse: Decodable {
    
}

struct Weather: Decodable {
    
}
