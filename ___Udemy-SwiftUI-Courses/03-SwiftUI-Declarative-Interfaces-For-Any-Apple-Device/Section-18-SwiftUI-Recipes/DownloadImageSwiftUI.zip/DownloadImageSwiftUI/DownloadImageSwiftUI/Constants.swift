//
//  Constants.swift
//  DownloadImageSwiftUI
//
//  Created by Mohammad Azam on 9/26/19.
//  Copyright © 2019 Mohammad Azam. All rights reserved.
//

import Foundation

struct Constants {
    
    static let imageURL = "https://i.pinimg.com/originals/87/b1/5d/87b15d3ebd82b7605957c94f0945a7a4.png"
    
}
