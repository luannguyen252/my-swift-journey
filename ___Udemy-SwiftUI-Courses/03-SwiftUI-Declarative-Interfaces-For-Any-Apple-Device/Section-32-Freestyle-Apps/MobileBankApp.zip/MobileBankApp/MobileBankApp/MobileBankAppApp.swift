//
//  MobileBankAppApp.swift
//  MobileBankApp
//
//  Created by Mohammad Azam on 10/7/20.
//

import SwiftUI

@main
struct MobileBankAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
