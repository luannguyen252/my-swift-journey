//
//  NotificationView.swift
//  SwiftUIForAllDevices-watchOS Extension
//
//  Created by Mohammad Azam on 9/12/19.
//  Copyright © 2019 Mohammad Azam. All rights reserved.
//

import SwiftUI

struct NotificationView: View {
    var body: some View {
        Text("Hello World")
    }
}

#if DEBUG
struct NotificationView_Previews: PreviewProvider {
    static var previews: some View {
        NotificationView()
    }
}
#endif
