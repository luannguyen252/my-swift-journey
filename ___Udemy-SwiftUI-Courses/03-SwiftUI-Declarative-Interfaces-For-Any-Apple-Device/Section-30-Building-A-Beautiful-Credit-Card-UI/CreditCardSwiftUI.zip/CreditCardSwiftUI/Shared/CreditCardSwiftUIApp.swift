//
//  CreditCardSwiftUIApp.swift
//  Shared
//
//  Created by Mohammad Azam on 7/21/20.
//

import SwiftUI

@main
struct CreditCardSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
