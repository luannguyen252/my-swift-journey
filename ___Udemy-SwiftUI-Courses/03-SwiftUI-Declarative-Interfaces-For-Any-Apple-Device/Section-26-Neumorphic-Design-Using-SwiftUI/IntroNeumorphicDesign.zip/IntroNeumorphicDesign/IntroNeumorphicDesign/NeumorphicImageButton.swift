//
//  NeumorphicImageButton.swift
//  IntroNeumorphicDesign
//
//  Created by Mohammad Azam on 5/10/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import SwiftUI

struct NeumorphicImageButton: View {
    var body: some View {
        
        Button(action: {}) {
            
            // SF Symbols
            Image(systemName: "heart.fill")
            .resizable()
                .frame(width: 60, height: 60)
            .padding(30)
            .foregroundColor(Color(#colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)))
            .background(Color(#colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)))
            
        }.clipShape(Circle())
        .shadow(color: Color(#colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)), radius: 8, x: 8, y: 8)
        .shadow(color: Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)), radius: 8, x: -8, y: -8)
        
    }
}

struct NeumorphicImageButton_Previews: PreviewProvider {
    static var previews: some View {
        NeumorphicImageButton()
    }
}
