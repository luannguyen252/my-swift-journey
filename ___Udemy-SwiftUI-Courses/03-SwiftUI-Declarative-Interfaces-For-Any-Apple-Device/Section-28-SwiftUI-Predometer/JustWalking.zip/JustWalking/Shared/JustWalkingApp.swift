//
//  JustWalkingApp.swift
//  Shared
//
//  Created by Mohammad Azam on 7/7/20.
//

import SwiftUI

@main
struct JustWalkingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
