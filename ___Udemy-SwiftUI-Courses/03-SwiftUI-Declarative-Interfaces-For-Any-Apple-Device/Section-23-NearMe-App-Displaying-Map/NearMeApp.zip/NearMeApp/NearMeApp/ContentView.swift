//
//  ContentView.swift
//  NearMeApp
//
//  Created by Mohammad Azam on 3/24/20.
//  Copyright © 2020 Mohammad Azam. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject private var locationManager = LocationManager() 
    
    var body: some View {
        MapView() 
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
