//
//  LearnSwiftUIApp.swift
//  Shared
//
//  Created by Mohammad Azam on 6/26/20.
//

import SwiftUI

@main
struct LearnSwiftUIApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                
        }
    }
}
