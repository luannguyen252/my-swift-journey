//
//  GridSwiftUI2App.swift
//  GridSwiftUI2
//
//  Created by Mohammad Azam on 6/22/20.
//

import SwiftUI

@main
struct GridSwiftUI2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
