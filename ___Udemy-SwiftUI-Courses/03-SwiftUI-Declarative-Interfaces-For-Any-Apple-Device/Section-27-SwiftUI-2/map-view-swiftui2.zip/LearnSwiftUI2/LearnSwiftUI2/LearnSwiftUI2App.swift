//
//  LearnSwiftUI2App.swift
//  LearnSwiftUI2
//
//  Created by Mohammad Azam on 6/22/20.
//

import SwiftUI

@main
struct LearnSwiftUI2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
