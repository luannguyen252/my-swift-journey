
//
//  ContentView.swift
//  Shared
//
//  Created by Mohammad Azam on 6/27/20.
//

import SwiftUI

struct ContentView: View {
        
    let columns: [GridItem] = [
        GridItem(.adaptive(minimum: 100))

    ]
    
    var body: some View {
        
        ScrollView {
            LazyVGrid(columns: columns) {
                
                ForEach(1..<20) { _ in
                    Rectangle()
                        .fill(Color.red)
                        .aspectRatio(contentMode: .fit)
                }
            }.padding()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
