//
//  LazyGridsInSwiftUIApp.swift
//  Shared
//
//  Created by Mohammad Azam on 6/27/20.
//

import SwiftUI

@main
struct LazyGridsInSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
