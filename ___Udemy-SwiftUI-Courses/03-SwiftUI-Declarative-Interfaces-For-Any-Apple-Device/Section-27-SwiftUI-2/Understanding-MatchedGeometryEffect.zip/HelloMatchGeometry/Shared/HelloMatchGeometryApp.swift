//
//  HelloMatchGeometryApp.swift
//  Shared
//
//  Created by Mohammad Azam on 7/26/20.
//

import SwiftUI

@main
struct HelloMatchGeometryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView() 
        }
    }
}
