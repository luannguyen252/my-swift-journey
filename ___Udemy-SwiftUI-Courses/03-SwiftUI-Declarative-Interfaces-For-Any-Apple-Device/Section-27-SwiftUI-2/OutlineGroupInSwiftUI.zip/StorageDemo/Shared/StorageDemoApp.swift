//
//  StorageDemoApp.swift
//  Shared
//
//  Created by Mohammad Azam on 6/30/20.
//

import SwiftUI


@main
struct StorageDemoApp: App {
    
    var body: some Scene {
        WindowGroup {
           ContentView() 
        }
    }
}
