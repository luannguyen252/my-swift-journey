//
//  MoviesAppApp.swift
//  Shared
//
//  Created by Mohammad Azam on 7/4/20.
//

import SwiftUI

@main
struct MoviesAppApp: App {
    
    @StateObject var store = MovieStore()
    
    var body: some Scene {
        WindowGroup {
            ContentView(store: store)
        }
    }
}
