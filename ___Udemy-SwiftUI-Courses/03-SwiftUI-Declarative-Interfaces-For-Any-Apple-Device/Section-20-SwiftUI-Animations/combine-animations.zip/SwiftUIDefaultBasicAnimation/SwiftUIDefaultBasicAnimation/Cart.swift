//
//  Cart.swift
//  SwiftUIDefaultBasicAnimation
//
//  Created by Mohammad Azam on 9/23/19.
//  Copyright © 2019 Mohammad Azam. All rights reserved.
//

import SwiftUI

struct Cart: View {
    var body: some View {
        
        NavigationView {
            
            VStack {
                Text("ss")
            }
            
            
            .navigationBarTitle("iPhone 11")
        }
        
    }
}

struct Cart_Previews: PreviewProvider {
    static var previews: some View {
        Cart()
    }
}
