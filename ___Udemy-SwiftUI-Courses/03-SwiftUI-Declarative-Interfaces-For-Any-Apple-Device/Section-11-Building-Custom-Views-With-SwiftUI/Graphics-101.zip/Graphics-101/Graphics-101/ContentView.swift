//
//  ContentView.swift
//  Graphics-101
//
//  Created by Mohammad Azam on 6/22/19.
//  Copyright © 2019 Mohammad Azam. All rights reserved.
//

import SwiftUI

struct ContentView : View {
    var body: some View {
        
        VStack {
        
        Circle()
            .fill(Color.red)
            .frame(width: 200, height: 200)
            
        Circle()
            .stroke(Color.green, lineWidth: 20)
            
        Rectangle()
            .fill(Color.yellow)
            .frame(width: 100, height: 200)
            
        }
        
    }
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
