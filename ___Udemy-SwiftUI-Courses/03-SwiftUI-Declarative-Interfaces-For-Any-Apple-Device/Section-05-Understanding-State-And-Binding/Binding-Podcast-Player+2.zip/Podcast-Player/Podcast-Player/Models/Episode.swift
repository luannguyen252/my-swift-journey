

import Foundation

struct Episode {
    let name: String
    let track: String 
}

