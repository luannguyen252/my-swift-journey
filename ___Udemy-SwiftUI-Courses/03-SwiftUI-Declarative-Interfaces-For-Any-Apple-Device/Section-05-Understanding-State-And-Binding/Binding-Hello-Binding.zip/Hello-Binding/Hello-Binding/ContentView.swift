

import SwiftUI

struct ContentView : View {
    
    @State var name: String = ""
    
    private func printName() {
        print(self.name)
    }
    
    var body: some View {
        VStack {
            Text(name)
            TextField($name, placeholder: Text("Enter name"))
                .padding(12)
            
            Button(action: printName) {
                Text("Show Name Value")
            }
        }
        
    }
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
