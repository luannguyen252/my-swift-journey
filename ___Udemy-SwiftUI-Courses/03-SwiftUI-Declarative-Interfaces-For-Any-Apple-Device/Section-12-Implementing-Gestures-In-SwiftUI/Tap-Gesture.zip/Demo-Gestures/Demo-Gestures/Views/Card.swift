//
//  Card.swift
//  Demo-Gestures
//
//  Created by Mohammad Azam on 6/24/19.
//  Copyright © 2019 Mohammad Azam. All rights reserved.
//

import Foundation
import SwiftUI

struct Card: View {
    
    let tapped: Bool
    
    var body: some View {
        
        VStack {
            Text("Card")
                .font(.title)
                .color(Color.white)
            
            }.frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
            .background(self.tapped ? Color.orange : Color.purple)
            .cornerRadius(30)
        
    }
    
}

#if DEBUG

struct Card_Previews: PreviewProvider {
    static var previews: some View {
        Card(tapped: true)
    }
}

#endif
