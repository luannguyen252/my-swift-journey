//
//  ContentView.swift
//  Demo-Gestures
//
//  Created by Mohammad Azam on 6/24/19.
//  Copyright © 2019 Mohammad Azam. All rights reserved.
//

import SwiftUI

struct ContentView : View {
    
    @State private var tapped: Bool = false
    
    var body: some View {
        Card(tapped: self.tapped)
            .gesture(TapGesture(count: 1)
                .onEnded({ () in
                    self.tapped.toggle()
                })
        )
    }
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
