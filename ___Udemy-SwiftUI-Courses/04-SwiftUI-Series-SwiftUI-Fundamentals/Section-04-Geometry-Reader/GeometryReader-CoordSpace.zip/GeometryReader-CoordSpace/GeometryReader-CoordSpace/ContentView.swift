//
//  ContentView.swift
//  GeometryReader-CoordSpace
//
//  Created by Andi Setiyadi on 12/20/20.
//

import SwiftUI

struct ContentView: View {
  var body: some View {
    VStack(spacing: 0) {
      Text("OUTER")
        .frame(height: 30)
        .background(Color.black)
      
      VStack(spacing: 0) {
        Text("MID")
          .frame(height: 30)
          .background(Color.black)
        
        VStack(spacing: 0) {
          Text("INNER-TOP")
            .frame(height: 30)
            .background(Color.black)
          
          HStack(spacing: 0) {
            Text("L")
              .frame(width: 20)
              .background(Color.black)
            
            GeometryReader { geometry in
              VStack {
                // LOCAL
                HStack {
                  Text("In Local: (\(Int(geometry.frame(in: .local).minX)), \(Int(geometry.frame(in: .local).minY)))")
                  Spacer()
                }
                
                // GLOBAL
                HStack {
                  Text("In Global: (\(Int(geometry.frame(in: .global).minX)), \(Int(geometry.frame(in: .global).minY)))")
                  Spacer()
                }
                
                // CUSTOM COORDINATE SPACE
                HStack {
                  Text("In Blue-CoordSpace: (\(Int(geometry.frame(in: .named("blue")).minX)), \(Int(geometry.frame(in: .named("blue")).minY)))")
                  Spacer()
                }
                
                Spacer()
                
                HStack {
                  Text("Size: \(Int(geometry.size.width)) x \(Int(geometry.size.height))")
                }
                
                Spacer()
                
                HStack {
                  Text("(\(Int(geometry.frame(in: .local).minX)), \(Int(geometry.frame(in: .local).maxY)))")
                  
                  Spacer()
                  
                  Text("(\(Int(geometry.frame(in: .local).maxX)), \(Int(geometry.frame(in: .local).maxY)))")
                }
              }
            }
            .background(Color.purple)
            
            Text("R")
              .frame(width: 20)
              .background(Color.black)
          }
          
          Text("INNER-BOTTOM")
            .frame(height: 30)
            .background(Color.black)
        }
        .background(Color.green)
      }
      .background(Color.blue)
      .coordinateSpace(name: "blue")
    }
    .background(Color.yellow)
    .foregroundColor(.white)
  }
}

struct ContentView_Previews: PreviewProvider {
  static var previews: some View {
    ContentView()
  }
}
