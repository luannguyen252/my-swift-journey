//
//  GeometryReader_CoordSpaceApp.swift
//  GeometryReader-CoordSpace
//
//  Created by Andi Setiyadi on 12/20/20.
//

import SwiftUI

@main
struct GeometryReader_CoordSpaceApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
