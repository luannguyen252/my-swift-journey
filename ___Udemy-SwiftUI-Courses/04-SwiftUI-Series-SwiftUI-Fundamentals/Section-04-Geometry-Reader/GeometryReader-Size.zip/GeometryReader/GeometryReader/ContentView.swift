//
//  ContentView.swift
//  GeometryReader
//
//  Created by Andi Setiyadi on 12/18/20.
//

import SwiftUI

struct ContentView: View {
  var body: some View {
    VStack(spacing: 0) {
      Text("Text 1")
        .frame(height: 50)
        .background(Color.orange)
      
      GeometryReader { geo in
        Text("Geo-size: \(Int(geo.size.width)) x \(Int(geo.size.height))")
      }
      .background(Color.blue)
      
      HStack {
        Text("Left")
        
        GeometryReader { geo in
          Text("Geo-size: \(Int(geo.size.width)) x \(Int(geo.size.height))")
        }
        .background(Color.purple)
        
        Text("Right Text")
      }
      .frame(height: 100)
    }
    .frame(width: 300, height: 400, alignment: .center)
    .background(Color.yellow)
  }
}

struct ContentView_Previews: PreviewProvider {
  static var previews: some View {
    ContentView()
  }
}
