//
//  GeometryReaderApp.swift
//  GeometryReader
//
//  Created by Andi Setiyadi on 12/18/20.
//

import SwiftUI

@main
struct GeometryReaderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
