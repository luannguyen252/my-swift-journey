//
//  CustomViewBuilderApp.swift
//  CustomViewBuilder
//
//  Created by Andi Setiyadi on 12/14/20.
//

import SwiftUI

@main
struct CustomViewBuilderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
