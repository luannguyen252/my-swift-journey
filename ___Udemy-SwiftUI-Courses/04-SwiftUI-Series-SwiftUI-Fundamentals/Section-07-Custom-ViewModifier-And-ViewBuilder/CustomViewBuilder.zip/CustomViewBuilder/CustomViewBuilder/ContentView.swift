//
//  ContentView.swift
//  CustomViewBuilder
//
//  Created by Andi Setiyadi on 12/14/20.
//

import SwiftUI

struct ContentView: View {
  var body: some View {
    Button(action: { print("Button is tapped")}, label: {
      Text("Button")
    })
    
    RoundedButton {
      print("Rounded button is tapped")
    } label: {
      Text("Rounded button with View Builder")
    }
    
    RoundedWeatherButton(weather: .sunny) {
      print("Sunny button tapped")
    } content: {
      Text("Sunny")
    }

    RoundedWeatherButton(weather: .rain) {
      print("Raining button tapped")
    } content: {
      Text("Rain Cats and Dogs")
    }
  }
}

struct ContentView_Previews: PreviewProvider {
  static var previews: some View {
    ContentView()
  }
}
