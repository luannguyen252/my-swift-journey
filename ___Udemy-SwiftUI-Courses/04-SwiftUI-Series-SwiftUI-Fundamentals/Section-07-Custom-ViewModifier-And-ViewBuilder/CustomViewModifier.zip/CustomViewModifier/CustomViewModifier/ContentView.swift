//
//  ContentView.swift
//  CustomViewModifier
//
//  Created by Andi Setiyadi on 12/14/20.
//

import SwiftUI

struct ContentView: View {
  var body: some View {
    VStack(alignment: .center, spacing: 20) {
      Button("Basic Button") {
        print("Basic button is tapped")
      }
      .padding()
      .foregroundColor(.white)
      .background(Color.blue)
      
      Button(action: { print("Button Modifier is tapped")}, label: {
        Text("Rounded button view modifier")
      })
      .modifier(RoundedButtonModifier())
      
      Button(action: { print("Button Modifier is tapped")}, label: {
        Text("Rounded button view modifier with Extension")
      })
      .rounded()
    }
  }
}

struct ContentView_Previews: PreviewProvider {
  static var previews: some View {
    ContentView()
  }
}
