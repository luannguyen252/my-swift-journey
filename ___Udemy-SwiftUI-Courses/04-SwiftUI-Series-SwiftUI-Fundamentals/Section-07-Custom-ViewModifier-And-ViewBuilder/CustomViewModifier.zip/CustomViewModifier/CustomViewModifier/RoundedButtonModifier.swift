//
//  RoundedButtonModifier.swift
//  CustomViewModifier
//
//  Created by Andi Setiyadi on 12/14/20.
//

import SwiftUI

struct RoundedButtonModifier: ViewModifier {
  func body(content: Content) -> some View {
    content
      .font(.footnote)
      .padding(EdgeInsets(top: 10, leading: 20, bottom: 10, trailing: 20))
      .foregroundColor(.white)
      .background(RoundedRectangle(cornerRadius: .infinity)
                    .foregroundColor(.accentColor))
      .buttonStyle(BorderlessButtonStyle())
  }
}
