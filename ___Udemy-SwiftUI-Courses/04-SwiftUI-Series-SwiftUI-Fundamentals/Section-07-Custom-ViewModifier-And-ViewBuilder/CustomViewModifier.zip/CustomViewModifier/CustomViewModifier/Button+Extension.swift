//
//  Button+Extension.swift
//  CustomViewModifier
//
//  Created by Andi Setiyadi on 12/14/20.
//

import SwiftUI

extension Button {
  func rounded() -> some View {
    modifier(RoundedButtonModifier())
  }
}
