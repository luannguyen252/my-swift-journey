//
//  VerticalGrid.swift
//  Grid
//
//  Created by Andi Setiyadi on 12/28/20.
//

import SwiftUI

struct VerticalGrid: View {
  let items = (0...200)
  
//  let columns = [
//    GridItem(.fixed(100)),
//    GridItem(.fixed(100)),
//    GridItem(.fixed(100))
//  ]
  
//  let columns = [
//    GridItem(.adaptive(minimum: 100))
//  ]

//  let columns = [
//    GridItem(.flexible()),
//    GridItem(.flexible()),
//    GridItem(.flexible()),
//    GridItem(.flexible())
//  ]
  
  let columns = [
    GridItem(.fixed(150)),
    GridItem(.adaptive(minimum: 60))
  ]
  
  var body: some View {
    ScrollView {
      LazyVGrid(columns: columns) {
        ForEach(items, id: \.self) { item in
          ZStack {
            Circle()
              .strokeBorder(Color.blue, lineWidth: 4)
            
            Text("\(item)")
              .font(.title3)
              .padding()
          }
          .background(Color.yellow)
        }
      }
    }
  }
}

struct VerticalGrid_Previews: PreviewProvider {
  static var previews: some View {
    VerticalGrid()
  }
}
