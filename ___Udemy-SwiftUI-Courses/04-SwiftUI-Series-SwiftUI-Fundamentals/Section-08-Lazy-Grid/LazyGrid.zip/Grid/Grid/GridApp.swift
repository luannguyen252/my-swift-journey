//
//  GridApp.swift
//  Grid
//
//  Created by Andi Setiyadi on 12/28/20.
//

import SwiftUI

@main
struct GridApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
