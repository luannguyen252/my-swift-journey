//
//  ContentView.swift
//  Grid
//
//  Created by Andi Setiyadi on 12/28/20.
//

import SwiftUI

struct ContentView: View {
  var body: some View {
    NavigationView {
      VStack {
        NavigationLink("Vertical Grid", destination: VerticalGrid())
        NavigationLink("Horizontal Grid", destination: HorizontalGrid())
      }
      .navigationTitle("Lazy Grid")
    }
  }
}

struct ContentView_Previews: PreviewProvider {
  static var previews: some View {
    ContentView()
  }
}
