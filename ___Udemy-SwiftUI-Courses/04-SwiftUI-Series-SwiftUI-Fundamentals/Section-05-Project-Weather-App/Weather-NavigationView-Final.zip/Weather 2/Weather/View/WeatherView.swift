//
//  WeatherView.swift
//  Weather
//
//  Created by Andi Setiyadi on 11/23/20.
//

import SwiftUI

struct WeatherView: View {
  @State private var toggleSearchLocation = false
  
  var body: some View {
    GeometryReader { geo in
      NavigationView {
        VStack {

        }
        .navigationBarItems(trailing: Button(action: {
          self.toggleSearchLocation.toggle()
        }, label: {
          Image(systemName: "magnifyingglass")
            .resizable()
            .frame(width: 30, height: 30)
        }))
      }
      .sheet(isPresented: $toggleSearchLocation, content: {
        Text("Search Location")
      })
    }
  }
}

struct WeatherView_Previews: PreviewProvider {
  static var previews: some View {
    WeatherView()
  }
}
