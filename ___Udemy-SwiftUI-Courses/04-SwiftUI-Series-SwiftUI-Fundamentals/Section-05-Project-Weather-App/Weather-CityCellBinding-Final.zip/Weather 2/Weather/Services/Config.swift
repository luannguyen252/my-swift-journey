//
//  Config.swift
//  Weather
//
//  Created by Andi Setiyadi on 11/23/20.
//

import Foundation

enum Config {
  enum AccuWeather {
    // Insert your AccuWeather API Key here
    static let apiKey = ""
  }
}
