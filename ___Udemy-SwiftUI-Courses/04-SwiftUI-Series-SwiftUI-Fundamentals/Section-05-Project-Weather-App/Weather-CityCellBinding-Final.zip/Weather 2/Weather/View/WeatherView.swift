//
//  WeatherView.swift
//  Weather
//
//  Created by Andi Setiyadi on 11/23/20.
//

import SwiftUI

struct WeatherView: View {
  @ObservedObject var locationService = LocationService()
  @State private var toggleSearchLocation = false
  
  var body: some View {
    NavigationView {
      VStack {
        if let location = locationService.selectedLocation {
          Text("key: \(location.key) - name: \(location.localizedName)")
        }
      }
      .navigationBarItems(trailing: Button(action: {
        self.toggleSearchLocation.toggle()
      }, label: {
        Image(systemName: "magnifyingglass")
          .resizable()
          .frame(width: 30, height: 30)
      }))
    }
    .sheet(isPresented: $toggleSearchLocation, content: {
      SearchView(locationService: locationService)
    })
  }
}

struct WeatherView_Previews: PreviewProvider {
  static var previews: some View {
    WeatherView()
  }
}
