//
//  WeatherApp.swift
//  Weather
//
//  Created by Andi Setiyadi on 11/23/20.
//

import SwiftUI

@main
struct WeatherApp: App {
  let measurementType = MeasurementType(option: .imperial)
  
  var body: some Scene {
    let locationService = LocationService(measurementType: measurementType)
    
    WindowGroup {
      WeatherView(locationService: locationService)
        .environmentObject(measurementType)
    }
  }
}
