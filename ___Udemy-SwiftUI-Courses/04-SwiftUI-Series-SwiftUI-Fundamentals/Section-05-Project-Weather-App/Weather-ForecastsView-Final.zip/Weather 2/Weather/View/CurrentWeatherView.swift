//
//  CurrentWeatherView.swift
//  Weather
//
//  Created by Andi Setiyadi on 11/24/20.
//

import SwiftUI

struct CurrentWeatherView: View {
  var city: String
  var weather: CurrentWeather
  var hiLoForecast: Forecast?
  
  var body: some View {
    VStack(alignment: .center, spacing: 0) {
      Text(city)
        .font(.custom("Helvetica-Neue", size: 30))
      
      Text(weather.WeatherText)
        .font(.callout)
      
      Spacer()
      
      Text(Helper.temperatureDisplay(value: weather.Temperature.Imperial.Value,
                                     unit: .fahrenheit) + weather.Temperature.Imperial.Unit)
        .font(.custom("HelveticaNeue-Light", size: 60))
      
      if let forecast = hiLoForecast {
        Text("H:\(Helper.temperatureDisplay(value: forecast.Temperature.Maximum.Value, unit: .fahrenheit)) L:\(Helper.temperatureDisplay(value: forecast.Temperature.Minimum.Value, unit: .fahrenheit))")
          .font(.callout)
      }
      
      Spacer()
    }
    .frame(height: 160)
  }
}

struct CurrentWeatherView_Previews: PreviewProvider {
  static var previews: some View {
    CurrentWeatherView(city: "Denver",
                       weather: CurrentWeather.mock())
  }
}
