//
//  FiveDayForecastView.swift
//  Weather
//
//  Created by Andi Setiyadi on 11/25/20.
//

import SwiftUI

struct FiveDayForecastView: View {
  var forecasts: [Forecast]
  
  var body: some View {
    VStack(alignment: .leading, spacing: 10) {
      ForEach(forecasts, id: \.Date) { forecast in
        HStack(alignment: .center, spacing: 10) {
          Text(Helper.day(from: forecast.Date))
            .font(.title3)
            .frame(width: 110, alignment: .leading)
          
          Spacer()
          
          Image(Helper.iconName(phrase: forecast.Day.IconPhrase))
            .resizable()
            .frame(width: 20, height: 20, alignment: .center)
          
          Spacer()
          
          HStack(spacing: 20) {
            Text("\(Int(forecast.Temperature.Maximum.Value))")
              .frame(width: 30, alignment: .leading)
            
            Text("\(Int(forecast.Temperature.Minimum.Value))")
              .frame(width: 30, alignment: .leading)
              .opacity(0.5)
          }
          .frame(width: 100, alignment: .trailing)
        }
      }
    }
    .padding()
  }
}

struct FiveDayForecastView_Previews: PreviewProvider {
  static var previews: some View {
    FiveDayForecastView(forecasts: [Forecast.mock()])
  }
}
