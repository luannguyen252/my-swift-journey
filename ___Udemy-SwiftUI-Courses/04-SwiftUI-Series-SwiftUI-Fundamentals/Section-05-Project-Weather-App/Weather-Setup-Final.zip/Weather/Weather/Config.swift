//
//  Config.swift
//  Weather
//
//  Created by Andi Setiyadi on 11/23/20.
//

import Foundation

enum Config {
  enum AccuWeather {
    // Insert your Weather API here
    static let apiKey = ""
  }
}
