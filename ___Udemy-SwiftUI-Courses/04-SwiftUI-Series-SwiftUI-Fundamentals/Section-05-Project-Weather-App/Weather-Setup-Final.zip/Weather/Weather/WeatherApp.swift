//
//  WeatherApp.swift
//  Weather
//
//  Created by Andi Setiyadi on 11/23/20.
//

import SwiftUI

@main
struct WeatherApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
  }
}
