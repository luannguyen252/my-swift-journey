//
//  WeatherView.swift
//  Weather
//
//  Created by Andi Setiyadi on 11/23/20.
//

import SwiftUI

struct WeatherView: View {
  @ObservedObject var locationService = LocationService()
  @State private var toggleSearchLocation = false
  
  var body: some View {
    GeometryReader { geo in
      NavigationView {
        ZStack(alignment: .center) {
          Image(locationService.currentWeather?.IsDayTime ?? true ? "bgDay" : "bgNight")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .edgesIgnoringSafeArea(.all)
          
          VStack {
            if let location = locationService.selectedLocation,
               let weather = locationService.currentWeather {
              CurrentWeatherView(city: location.localizedName,
                                 weather: weather)
            }
          }
          .navigationBarItems(trailing: Button(action: {
            self.toggleSearchLocation.toggle()
          }, label: {
            Image(systemName: "magnifyingglass")
              .resizable()
              .frame(width: 30, height: 30)
          }))
        }
        .sheet(isPresented: $toggleSearchLocation, content: {
          SearchView(locationService: locationService)
        })
      }
    }
  }
}

struct WeatherView_Previews: PreviewProvider {
  static var previews: some View {
    WeatherView()
  }
}
