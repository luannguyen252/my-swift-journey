//
//  Helper.swift
//  Weather
//
//  Created by Andi Setiyadi on 11/24/20.
//

import Foundation

class Helper {
  static func temperatureDisplay(value: Double, unit: UnitTemperature) -> String {
    let measurement = Measurement(value: value, unit: unit)
    
    let formatter = MeasurementFormatter()
    formatter.unitStyle = .short
    formatter.numberFormatter.maximumFractionDigits = 0
    formatter.unitOptions = .temperatureWithoutUnit
    
    return formatter.string(from: measurement)
  }
}
