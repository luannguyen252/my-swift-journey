//
//  CurrentWeather.swift
//  Weather
//
//  Created by Andi Setiyadi on 11/24/20.
//

import Foundation

struct CurrentWeather: Codable {
  let WeatherText: String
  let IsDayTime: Bool
  let Temperature: TemperatureUnit
  
  struct TemperatureUnit: Codable {
    let Metric: TemperatureValue
    let Imperial: TemperatureValue
  }
}

extension CurrentWeather {
  static func mock() -> CurrentWeather {
    return CurrentWeather(WeatherText: "Mostly Sunny",
                          IsDayTime: true,
                          Temperature: CurrentWeather.TemperatureUnit(Metric: TemperatureValue(Value: 55, Unit: "F"),
                                                                      Imperial: TemperatureValue(Value: 12.8, Unit: "C")))
  }
}

struct TemperatureValue: Codable {
  let Value: Double
  let Unit: String
}
