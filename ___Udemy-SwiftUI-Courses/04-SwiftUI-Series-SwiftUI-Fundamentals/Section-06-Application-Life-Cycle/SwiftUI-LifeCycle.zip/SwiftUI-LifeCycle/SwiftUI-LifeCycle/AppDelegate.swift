//
//  AppDelegate.swift
//  SwiftUI-LifeCycle
//
//  Created by Andi Setiyadi on 12/14/20.
//

import UIKit

class AppDelegate: UIResponder, UIApplicationDelegate {
  func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    print("application  - didFinishLaunching")
    
    return true
  }
}
