//
//  SwiftUI_LifeCycleApp.swift
//  SwiftUI-LifeCycle
//
//  Created by Andi Setiyadi on 12/14/20.
//

import SwiftUI

@main
struct SwiftUI_LifeCycleApp: App {
  
  @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
  
  @Environment(\.scenePhase) var scenePhase
  
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
    .onChange(of: scenePhase) { phase in
      switch phase {
      case .active:
        print("Scene - ACTIVE")
        
      case .inactive:
        print("Scene - INACTIVE")
        
      case .background:
        print("Scene - BACKGROUND")
        
      @unknown default:
        print("Scene - UNKNOWN")
      }
    }
  }
}
