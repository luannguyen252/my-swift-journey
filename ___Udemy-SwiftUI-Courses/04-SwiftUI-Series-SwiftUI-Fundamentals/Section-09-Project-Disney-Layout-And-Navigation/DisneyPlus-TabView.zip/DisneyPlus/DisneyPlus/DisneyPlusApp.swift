//
//  DisneyPlusApp.swift
//  DisneyPlus
//
//  Created by Andi Setiyadi on 12/15/20.
//

import SwiftUI

@main
struct DisneyPlusApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
