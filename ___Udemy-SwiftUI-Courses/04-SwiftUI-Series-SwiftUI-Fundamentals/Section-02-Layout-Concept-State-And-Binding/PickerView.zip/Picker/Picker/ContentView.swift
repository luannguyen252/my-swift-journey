//
//  ContentView.swift
//  Picker
//
//  Created by Andi Setiyadi on 12/28/20.
//

import SwiftUI

struct ContentView: View {
  private let languages = ["Swift", "Objective-C", "Java", "C++"]
  @State private var languageSelection = 0
  @State private var dateSelected = Date()
  @State private var colorSelected = Color.yellow
  
  var body: some View {
    VStack {
      Picker(selection: $languageSelection, label: Text("Select Language")) {
        ForEach(0..<languages.count, id: \.self) { idx in
          Text(languages[idx]).tag(idx)
        }
      }
//      .pickerStyle(MenuPickerStyle())
      .pickerStyle(SegmentedPickerStyle())
      .padding()
      
      Text(languages[languageSelection])
      
      DatePicker("Select Date", selection: $dateSelected)
      
      ColorPicker("Select Color", selection: $colorSelected)
    }
  }
}

struct ContentView_Previews: PreviewProvider {
  static var previews: some View {
    ContentView()
  }
}
