//
//  PickerApp.swift
//  Picker
//
//  Created by Andi Setiyadi on 12/28/20.
//

import SwiftUI

@main
struct PickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
