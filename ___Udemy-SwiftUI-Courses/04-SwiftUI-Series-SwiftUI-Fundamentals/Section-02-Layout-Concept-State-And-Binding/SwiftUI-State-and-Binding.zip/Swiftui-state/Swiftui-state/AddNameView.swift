//
//  AddNameView.swift
//  Swiftui-state
//
//  Created by Andi Setiyadi on 11/20/20.
//

import SwiftUI

struct AddNameView: View {
//  @ObservedObject var contentVM: ContentViewModel
  @EnvironmentObject var contentVM: ContentViewModel
  @Binding var showForm: Bool
  
  var body: some View {
    TextField("Enter new name",
              text: $contentVM.name,
              onEditingChanged: { _ in },
              onCommit: {
                contentVM.save()
                showForm = false
              })
      .padding()
  }
}

struct AddNameView_Previews: PreviewProvider {
  static var previews: some View {
//    AddNameView(contentVM: ContentViewModel(),
//                showForm: .constant(true))
    
    AddNameView(showForm: .constant(true))
      .environmentObject(ContentViewModel())
  }
}
