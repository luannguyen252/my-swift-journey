//
//  ContentView.swift
//  Swiftui-state
//
//  Created by Andi Setiyadi on 11/20/20.
//

import SwiftUI

struct ContentView: View {
//  @ObservedObject var contentVM = ContentViewModel()
  @EnvironmentObject var contentVM: ContentViewModel
  @State private var showForm = false
  
  var body: some View {
    VStack {
      List(contentVM.names, id: \.self) { name in
        Text(name)
      }
      .padding(.top, 60)
      .frame(height: 400)
      
      Button(action: {
        contentVM.name = ""
        self.showForm = true
      }, label: {
        Text("Add Name")
      })
    }
    .sheet(isPresented: $showForm) {
//      AddNameView(contentVM: contentVM,
//                  showForm: $showForm)
      
      AddNameView(showForm: $showForm)
    }
  }
}

struct ContentView_Previews: PreviewProvider {
  static var previews: some View {
    ContentView()
  }
}
