//
//  ContentViewModel.swift
//  Swiftui-state
//
//  Created by Andi Setiyadi on 11/20/20.
//

import SwiftUI

class ContentViewModel: ObservableObject {
  @Published var names = ["Bob", "Susan"]
  
  var name: String = ""
  
  func save() {
    names.append(name)
  }
}
