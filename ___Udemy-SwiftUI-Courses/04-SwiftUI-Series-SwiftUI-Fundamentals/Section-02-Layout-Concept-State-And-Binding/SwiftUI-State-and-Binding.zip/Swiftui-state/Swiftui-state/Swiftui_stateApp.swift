//
//  Swiftui_stateApp.swift
//  Swiftui-state
//
//  Created by Andi Setiyadi on 11/20/20.
//

import SwiftUI

@main
struct Swiftui_stateApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
        .environmentObject(ContentViewModel())
    }
  }
}
