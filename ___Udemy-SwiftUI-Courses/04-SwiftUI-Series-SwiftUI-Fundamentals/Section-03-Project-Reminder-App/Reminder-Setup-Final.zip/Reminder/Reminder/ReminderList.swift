//
//  ReminderList.swift
//  Reminder
//
//  Created by Andi Setiyadi on 11/19/20.
//

import SwiftUI

struct ReminderList: View {
  var body: some View {
    NavigationView {
      VStack(alignment: .leading, spacing: 10) {
        List(mockReminder, id: \.id) { reminder in
          Text(reminder.name)
        }
        .padding(.horizontal, -20)
        
        Button(action: { print("Button tapped") }) {
          HStack {
            Image(systemName: "plus.circle.fill")
              .resizable()
              .frame(width: 25, height: 25, alignment: .center)
            
            Text("New Reminder")
          }
          .padding()
        }
      }
      .navigationBarTitle("Reminder")
      .navigationBarItems(trailing: EditButton())
    }
  }
}

struct ReminderList_Previews: PreviewProvider {
  static var previews: some View {
    ReminderList()
  }
}
