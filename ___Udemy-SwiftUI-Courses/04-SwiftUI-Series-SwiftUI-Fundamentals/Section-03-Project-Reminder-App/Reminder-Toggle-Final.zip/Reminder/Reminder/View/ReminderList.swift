//
//  ReminderList.swift
//  Reminder
//
//  Created by Andi Setiyadi on 11/19/20.
//

import SwiftUI

struct ReminderList: View {
  @ObservedObject var reminderManager = ReminderManager.shared
  @State private var hideCompleted = false
  @State private var addReminder = false
  @State private var sortByName = false
  
  var body: some View {
    NavigationView {
      VStack(alignment: .leading, spacing: 10) {
        List {
          Toggle("Hide completed", isOn: $hideCompleted)
          
          ForEach(reminderManager.reminders, id: \.id) { reminder in
            if !hideCompleted || !reminder.completed {
              ReminderCell(vm: ReminderCellViewModel(reminder: reminder))
            }
          }
          
          if addReminder {
            ReminderCell(vm: ReminderCellViewModel(reminder: Reminder.new()))
          }
        }
        .padding(.horizontal, -20)
        
        HStack {
          Button(action: { toggleAddForm() }) {
            HStack {
              Image(systemName: "plus.circle.fill")
                .resizable()
                .frame(width: 25, height: 25, alignment: .center)
              
              Text("New Reminder")
            }
            .padding()
          }
          
          Spacer()
          
          if addReminder {
            Button(action: { self.toggleAddForm() }, label: {
              Text("Done")
            })
            .padding()
          }
        }
      }
      .navigationBarTitle("Reminder")
      .navigationBarItems(trailing: EditButton())
    }
  }
  
  private func toggleAddForm() {
    addReminder.toggle()
  }
}

struct ReminderList_Previews: PreviewProvider {
  static var previews: some View {
    ReminderList()
  }
}
