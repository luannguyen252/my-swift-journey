//
//  ReminderCellViewModel.swift
//  Reminder
//
//  Created by Andi Setiyadi on 11/20/20.
//

import SwiftUI

class ReminderCellViewModel: ObservableObject {
  @Published var reminder: Reminder
  
  init(reminder: Reminder) {
    self.reminder = reminder
  }
  
  func setReminder() {
    ReminderManager.shared.set(reminder)
  }
}
