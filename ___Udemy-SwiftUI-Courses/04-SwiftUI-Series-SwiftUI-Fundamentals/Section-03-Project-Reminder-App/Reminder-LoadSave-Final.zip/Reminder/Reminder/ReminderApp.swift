//
//  ReminderApp.swift
//  Reminder
//
//  Created by Andi Setiyadi on 11/19/20.
//

import SwiftUI

@main
struct ReminderApp: App {
    var body: some Scene {
        WindowGroup {
            ReminderList()
        }
    }
}
