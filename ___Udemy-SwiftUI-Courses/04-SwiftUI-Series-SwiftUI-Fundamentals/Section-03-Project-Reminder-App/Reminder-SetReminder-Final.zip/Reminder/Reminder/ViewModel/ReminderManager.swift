//
//  ReminderManager.swift
//  Reminder
//
//  Created by Andi Setiyadi on 11/20/20.
//

import Foundation

class ReminderManager: ObservableObject {
  static let shared = ReminderManager()
  
  @Published var reminders = [Reminder]()
  
  private init() {
    loadReminders()
  }
  
  private func loadReminders() {
    
  }
  
  func set(_ reminder: Reminder) {
    reminders.append(reminder)
  }
}
