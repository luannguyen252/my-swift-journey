class Employee {
   var name = "Undefined"
   var age = 0
}
