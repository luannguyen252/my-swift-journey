var text = "Hello World"
if !text.isEmpty {
   let start = text.startIndex
   let firstChar = text[start]
    
   print("First character is \(firstChar)")  // "First character is H"
}
