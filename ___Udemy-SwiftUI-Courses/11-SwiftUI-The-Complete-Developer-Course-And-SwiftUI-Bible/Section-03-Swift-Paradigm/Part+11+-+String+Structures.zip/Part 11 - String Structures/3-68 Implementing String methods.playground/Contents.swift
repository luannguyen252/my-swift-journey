let text = "Hello World"

if text.hasSuffix("World") {
   print(text.uppercased())  // "HELLO WORLD"
}
