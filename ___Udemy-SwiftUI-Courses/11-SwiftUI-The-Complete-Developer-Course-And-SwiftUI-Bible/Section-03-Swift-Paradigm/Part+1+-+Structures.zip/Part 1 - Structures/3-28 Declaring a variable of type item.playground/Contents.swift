struct Item {
   var name: String = "Not defined"
   var price: Double = 0
}
var purchase: Item = Item()
