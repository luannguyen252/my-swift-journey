var units = "45"

if let number = Int(units) {
   let total = number + 15
   print("The total is \(total)")  // "The total is 60"
}
