var mynumber = Int(25)
var myprice = Double(4.99)
