var mynumber: Double = 2.890
mynumber = mynumber.rounded(.toNearestOrAwayFromZero)
print("The round number is \(mynumber)")  // "The round number is 3.0"
