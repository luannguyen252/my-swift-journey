class Employee {
   private var name = "Undefined"
   private var age = 0

   func showValues() {
      print("Name: \(name)")
      print("Age: \(age)")
   }
}
let employee = Employee()
employee.showValues()

