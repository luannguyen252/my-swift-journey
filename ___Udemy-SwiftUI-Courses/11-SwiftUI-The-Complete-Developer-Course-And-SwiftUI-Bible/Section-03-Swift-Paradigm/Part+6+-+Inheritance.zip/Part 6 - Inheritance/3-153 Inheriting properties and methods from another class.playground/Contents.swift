class Employee {
   var name = "Undefined"
   var age = 0
    
   func createbadge() -> String {
      return "Employee \(name) \(age)"
   }
}
class OfficeEmployee: Employee {
   var department = "Undefined"
}
