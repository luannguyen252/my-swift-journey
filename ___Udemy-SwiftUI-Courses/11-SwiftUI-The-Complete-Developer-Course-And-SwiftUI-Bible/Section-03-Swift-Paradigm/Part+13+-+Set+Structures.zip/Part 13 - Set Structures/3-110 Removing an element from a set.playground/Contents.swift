var fruits: Set = ["Apple", "Orange", "Banana"]

if let removed = fruits.remove("Banana") {
   print("\(removed) was removed")  // "Banana was removed"
}
