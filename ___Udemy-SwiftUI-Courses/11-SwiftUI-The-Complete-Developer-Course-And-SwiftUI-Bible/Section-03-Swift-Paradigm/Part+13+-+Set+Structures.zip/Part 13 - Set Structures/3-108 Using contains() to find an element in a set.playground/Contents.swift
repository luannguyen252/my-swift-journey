var fruits: Set = ["Apple", "Orange", "Banana"]

if fruits.contains("Apple") {
   print("Apple exists!")
}
