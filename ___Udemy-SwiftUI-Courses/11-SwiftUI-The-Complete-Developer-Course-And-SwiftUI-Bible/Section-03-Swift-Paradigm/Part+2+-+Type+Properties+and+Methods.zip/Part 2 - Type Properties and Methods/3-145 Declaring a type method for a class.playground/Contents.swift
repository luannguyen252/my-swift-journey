class Employee {
   var name = "Undefined"
   var age = 0

   class func description() {
      print("This class stores the name and age of an employee")
   }
}
Employee.description()
