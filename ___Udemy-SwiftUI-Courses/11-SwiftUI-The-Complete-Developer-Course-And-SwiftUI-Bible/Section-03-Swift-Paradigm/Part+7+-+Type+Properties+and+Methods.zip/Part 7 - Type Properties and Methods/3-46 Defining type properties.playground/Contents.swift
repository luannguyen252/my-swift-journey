struct Price {
   var USD: Double
   var CAD: Double

   static var currencies = 2
}
print(Price.currencies)  // 2
