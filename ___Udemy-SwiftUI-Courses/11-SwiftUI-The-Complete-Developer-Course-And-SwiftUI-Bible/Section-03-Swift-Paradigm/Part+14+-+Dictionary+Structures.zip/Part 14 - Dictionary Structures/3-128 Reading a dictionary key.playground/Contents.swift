var fruits = ["one": "Banana", "two": "Apple", "three": "Pear"]
let keys = Array(fruits.keys)
print(keys)
