var list = ["First": "Apple", "Second": "Orange"]
list["First"] = nil 
list 
