var list = ["First": "Apple", "Second": "Orange"]
list["Second"] = "Banana"
