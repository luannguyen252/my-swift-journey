var list = ["First": "Apple", "Second": "Orange"]
list["Third"] = "Banana"
print(list)  // "["Second": "Orange", "First": "Apple", "Third": "Banana"]"
