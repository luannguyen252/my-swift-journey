let reference = Int.self
let newnumber = reference.init(20)
print(newnumber)  // "20"
