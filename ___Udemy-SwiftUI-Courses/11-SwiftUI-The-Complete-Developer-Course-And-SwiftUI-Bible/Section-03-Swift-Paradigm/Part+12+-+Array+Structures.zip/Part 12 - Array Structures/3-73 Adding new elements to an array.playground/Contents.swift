var list = [15, 25, 35]
list += [45, 55]
print(list)  // [15, 25, 35, 45, 55]
