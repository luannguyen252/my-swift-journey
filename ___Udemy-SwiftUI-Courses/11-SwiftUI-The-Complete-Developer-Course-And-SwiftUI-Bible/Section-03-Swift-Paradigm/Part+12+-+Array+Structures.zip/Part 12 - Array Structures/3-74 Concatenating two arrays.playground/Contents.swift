var list1 = [15, 25, 35]
var list2 = [45, 55, 65]
var final = list1 + list2  // [15, 25, 35, 45, 55, 65]
