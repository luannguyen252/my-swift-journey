var fruits = ["Apple", "Blueberry", "Banana"]
var array = Array(fruits.reversed())  // ["Banana", "Blueberry", "Apple"]
