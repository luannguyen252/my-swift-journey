var list = [15, 25, 35]
print(list[1])  // 25
