var total = 0
let list = [15, 25, 35]

for value in list {
   total += value
}
print("The total is \(total)")  // "The total is 75"
