let ages = [32, 540, 12, 27, 54]
let index = 3
if index > 0 && index < ages.count {
   print("The value is: \(ages[index])")  // "The value is: 27"
}
