var list = [15, 25, 35]
list[0] = 400
print(list)  // [400, 25, 35]
