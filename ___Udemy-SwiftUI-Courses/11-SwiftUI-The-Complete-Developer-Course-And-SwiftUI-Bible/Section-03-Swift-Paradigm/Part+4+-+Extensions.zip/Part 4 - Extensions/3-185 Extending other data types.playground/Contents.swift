
extension Int {
   func printdescription() {
      print("The number is \(self)")
   }
}
let number = 25
number.printdescription()  // "The number is 25"
