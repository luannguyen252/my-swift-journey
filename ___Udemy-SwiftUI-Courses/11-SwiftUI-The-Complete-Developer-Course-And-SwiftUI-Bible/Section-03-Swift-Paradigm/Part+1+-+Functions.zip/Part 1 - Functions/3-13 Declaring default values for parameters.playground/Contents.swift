func sayhello(name: String = "Undefined") -> String {
   return "Your name is " + name
}
let message = sayhello()  // "Your name is Undefined"
