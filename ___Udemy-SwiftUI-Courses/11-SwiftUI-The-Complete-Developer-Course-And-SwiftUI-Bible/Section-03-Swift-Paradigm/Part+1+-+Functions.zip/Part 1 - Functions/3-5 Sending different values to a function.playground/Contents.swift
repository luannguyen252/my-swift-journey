func double(number: Int) {
   let total = number * 2
   let message = "Result: \(total)"
}
double(number: 5)  // "Result: 10"
double(number: 25)  // "Result: 50"
