func double(number: Int) -> Int {
   number * 2
}
let result = double(number: 25)
let message = "The result is \(result)"  // "The result is 50"
