var mynumber = 5
func myfunction() {
   mynumber = mynumber * 2  // 10
}
myfunction()
