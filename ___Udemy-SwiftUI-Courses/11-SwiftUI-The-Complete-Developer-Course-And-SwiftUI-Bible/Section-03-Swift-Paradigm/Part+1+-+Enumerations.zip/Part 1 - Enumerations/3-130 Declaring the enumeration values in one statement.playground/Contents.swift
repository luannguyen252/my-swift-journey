enum Number {
   case one, two, three
}
