enum Number {
   case one, two, three
}
var mynumber = Number.one
mynumber = .two
