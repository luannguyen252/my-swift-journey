enum Number {
   case one
   case two
   case three
}
