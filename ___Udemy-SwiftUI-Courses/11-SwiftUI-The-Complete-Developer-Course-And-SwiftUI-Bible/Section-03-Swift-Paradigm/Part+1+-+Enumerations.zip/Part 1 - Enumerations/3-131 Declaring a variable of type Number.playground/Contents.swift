enum Number {
   case one, two, three
}
var mynumber: Number = Number.one
