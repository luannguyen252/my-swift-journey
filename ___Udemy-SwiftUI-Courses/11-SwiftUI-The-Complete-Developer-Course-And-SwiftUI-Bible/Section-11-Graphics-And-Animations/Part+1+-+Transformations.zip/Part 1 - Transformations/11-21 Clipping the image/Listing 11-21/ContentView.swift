
import SwiftUI

struct ContentView: View {
   var body: some View {
      Image("book1")
         .resizable()
         .scaledToFit()
         .frame(width: 100, height: 180)
         .clipShape(Circle())
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
