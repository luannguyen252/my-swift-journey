
import SwiftUI

struct ContentView: View {
   var body: some View {
      Image("book1")
         .resizable()
         .scaledToFit()
         .frame(width: 100, height: 180)
         .scaleEffect(CGSize(width: 0.9, height: 0.9))
         .rotation3DEffect(.degrees(30), axis: (x: 0, y: 1, z: 0))
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
