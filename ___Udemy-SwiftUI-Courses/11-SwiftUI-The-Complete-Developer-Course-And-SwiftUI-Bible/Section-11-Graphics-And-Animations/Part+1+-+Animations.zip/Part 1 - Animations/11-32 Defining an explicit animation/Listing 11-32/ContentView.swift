
import SwiftUI

struct ContentView: View {
   @State private var roundCorners: Bool = false

   var body: some View {
      VStack {
         HStack {
            Rectangle()
               .fill(Color.blue)
               .frame(width: 100, height: 100)
               .cornerRadius(roundCorners ? 20 : 0)
            Rectangle()
               .fill(Color.blue)
               .frame(width: 100, height: 100)
               .cornerRadius(roundCorners ? 20 : 0)
         }.frame(width: 250, height: 120)
         Button("Animate") {
            withAnimation(Animation.easeOut) {
               self.roundCorners.toggle()
            }
         }
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
