
import SwiftUI

struct ContentView: View {
   @State private var showInfo = false

   var body: some View {
      VStack {
         Button("Show Information") {
            self.showInfo.toggle()
         }.padding()
         if showInfo {
            Text("This is the information")
               .transition(AnyTransition.scale.animation(.easeInOut))
         }
         Spacer()
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
