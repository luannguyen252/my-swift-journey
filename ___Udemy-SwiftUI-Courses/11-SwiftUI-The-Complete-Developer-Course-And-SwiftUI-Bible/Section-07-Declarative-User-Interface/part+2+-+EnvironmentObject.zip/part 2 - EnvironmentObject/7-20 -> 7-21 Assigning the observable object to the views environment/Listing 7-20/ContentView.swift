
import SwiftUI

class ContentViewData: ObservableObject {
   @Published var titleInput: String = ""
   @Published var authorInput: String = ""
}
struct ContentView: View {
   @ObservedObject var contentData = ContentViewData()
   @EnvironmentObject var appData: AppData

   var body: some View {
      VStack(spacing: 8) {
         Text("\(appData.title) - \(appData.author)")
            .padding(10)
         TextField("Insert Title", text: $contentData.titleInput)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         TextField("Insert Author", text: $contentData.authorInput)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         Button(action: {
            self.appData.title = self.contentData.titleInput
            self.appData.author = self.contentData.authorInput
         }, label: { Text("Save") })
         Spacer()
      }.padding()
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      ContentView().environmentObject(AppData())
   }
}
