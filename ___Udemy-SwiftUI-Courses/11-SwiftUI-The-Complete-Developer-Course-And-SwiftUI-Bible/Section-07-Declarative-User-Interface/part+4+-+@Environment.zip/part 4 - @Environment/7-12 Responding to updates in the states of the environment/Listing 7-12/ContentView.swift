
import SwiftUI

struct ContentView: View {
   @Environment(\.colorScheme) var mode

   var body: some View {
      Text("Mode: \(mode == .dark ? "Dark" : "Light")")
         .padding(30)
         .background(mode == .dark ? Color.black : Color.yellow)
         .foregroundColor(mode == .dark ? Color.white : Color.black)
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.colorScheme, .light)
    }
}
