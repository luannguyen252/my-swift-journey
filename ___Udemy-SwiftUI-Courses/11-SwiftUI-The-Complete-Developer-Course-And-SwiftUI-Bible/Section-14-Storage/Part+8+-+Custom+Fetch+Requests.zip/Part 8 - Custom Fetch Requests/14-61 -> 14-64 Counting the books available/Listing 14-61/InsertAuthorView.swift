
import SwiftUI
import CoreData

struct InsertAuthorView: View {
   @Environment(\.managedObjectContext) var dbContext
   @Environment(\.presentationMode) var presentation
   @State private var inputName: String = ""

   var body: some View {
      VStack {
         HStack {
            Text("Name:")
            TextField("Insert Name", text: $inputName)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Spacer()
            Button("Save") {
               let newName = self.inputName.trimmingCharacters(in: .whitespaces)
               if !newName.isEmpty {
                  let request: NSFetchRequest<Authors> = Authors.fetchRequest()
                  request.predicate = NSPredicate(format: "name = %@", newName)
                  if let total = try? self.dbContext.count(for: request), total == 0 {
                     let newAuthor = Authors(context: self.dbContext)
                     newAuthor.name = newName
                     do {
                        try self.dbContext.save()
                     } catch {
                        print("Error saving record")
                     }
                  }
               }
               self.presentation.wrappedValue.dismiss()
            }
         }
         Spacer()
      }.padding()
      .navigationBarTitle("Add Author")
   }
}
struct InsertAuthorView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext
      return InsertAuthorView()
         .environment(\.managedObjectContext, dbContext)
   }
}
