
import SwiftUI
import CoreData

class ModifyData: ObservableObject {
   @Published var selectedAuthor: Authors? = nil
   @Published var inputTitle: String = ""
   @Published var inputYear: String = ""
}
struct ModifyBookView: View {
   @Environment(\.managedObjectContext) var dbContext
   @Environment(\.presentationMode) var presentation
   @ObservedObject var modifyData = ModifyData()

   let book: Books
   init(book: Books) {
      self.book = book
      self.modifyData.selectedAuthor = book.author
      self.modifyData.inputTitle = book.title ?? "Undefined"
      self.modifyData.inputYear = book.showYear
   }
   var body: some View {
      VStack(spacing: 12) {
         HStack {
            Text("Title:")
            TextField("Insert Title", text: $modifyData.inputTitle)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Text("Year:")
            TextField("Insert Year", text: $modifyData.inputYear)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack(alignment: .top) {
            Text("Author:")
            VStack(alignment: .leading, spacing: 8) {
               Text(self.modifyData.selectedAuthor?.name ?? "Undefined")
                  .foregroundColor(self.modifyData.selectedAuthor != nil ? Color.black : Color.gray)
               NavigationLink(destination: AuthorsView(selected: self.$modifyData.selectedAuthor), label: {
                  Text("Select Author")
               })
            }
         }.frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
         Spacer()
      }.padding()
      .navigationBarTitle("Modify Book")
      .navigationBarItems(trailing: Button("Save") {
         let newTitle = self.modifyData.inputTitle.trimmingCharacters(in: .whitespaces)
         let newYear = Int32(self.modifyData.inputYear)
         if !newTitle.isEmpty && newYear != nil {
            self.book.title = newTitle
            self.book.year = newYear!
            self.book.author = self.modifyData.selectedAuthor
            do {
               try self.dbContext.save()
               self.presentation.wrappedValue.dismiss()
            } catch {
               print("Error saving record")
            }
         }
      })
   }
}
struct ModifyBookView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext

      let book = Books(context: dbContext)
      book.title = "Test"
      book.year = 1990
      return ModifyBookView(book: book)
         .environment(\.managedObjectContext, dbContext)
   }
}
