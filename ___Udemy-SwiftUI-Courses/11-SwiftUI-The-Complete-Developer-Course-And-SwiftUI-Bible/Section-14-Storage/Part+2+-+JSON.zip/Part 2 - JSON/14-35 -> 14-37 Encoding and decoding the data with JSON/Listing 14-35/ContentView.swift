
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var openSheet: Bool = false

   var body: some View {
      NavigationView {
         List {
            ForEach(appData.userData) { book in
               RowBook(book: book)
            }
         }
         .navigationBarTitle("Books")
         .navigationBarItems(trailing: Button("Add Book") {
            self.openSheet = true
         })
         .sheet(isPresented: $openSheet) {
            InsertBookView(openSheet: self.$openSheet)
               .environmentObject(self.appData)
         }
      }
   }
}
struct RowBook: View {
   let book: BookViewModel

   var body: some View {
      HStack(alignment: .top) {
         Image(uiImage: book.cover)
            .resizable()
            .scaledToFit()
            .frame(width: 80, height: 100)
            .cornerRadius(10)
         VStack(alignment: .leading, spacing: 2) {
            Text(book.title).bold()
            Text(book.author)
            Text(book.year).font(.caption)
            Spacer()
         }.padding(.top, 5)
         Spacer()
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(AppData())
    }
}
