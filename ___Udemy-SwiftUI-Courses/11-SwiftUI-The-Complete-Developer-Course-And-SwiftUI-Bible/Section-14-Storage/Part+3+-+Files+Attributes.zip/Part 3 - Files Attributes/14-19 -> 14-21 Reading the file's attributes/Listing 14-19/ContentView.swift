
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var openSheet: Bool = false

   var body: some View {
      NavigationView {
         VStack {
            Picker("", selection: self.$appData.currentDirectory) {
               ForEach(0..<self.appData.directories.count) { index in
                  Text(self.appData.directories[index]).tag(index)
               }
            }.labelsHidden()
            .pickerStyle(SegmentedPickerStyle())

            List {
               ForEach(self.appData.listOfFiles[self.appData.currentDirectory] ?? []) { file in
                  NavigationLink(destination: FileDetailsView(file: file.id), label: {
                     RowFile(file: file)
                  })
               }
            }
         }
         .navigationBarTitle("Files")
         .navigationBarItems(trailing: Button("Add File") {
            self.openSheet = true
         }.disabled(self.appData.currentDirectory != 0 ? true : false))
         .sheet(isPresented: $openSheet) {
            AddFileView(openSheet: self.$openSheet)
               .environmentObject(self.appData)
         }
      }
   }
}
struct RowFile: View {
   @EnvironmentObject var appData: AppData
   let file: File

   var body: some View {
      HStack {
         Text(file.name)
         Spacer()
         if self.appData.currentDirectory == 0 {
            Button(action: {
               self.appData.moveToArchived(name: self.file.name)
            }, label: {
               Image(systemName: "folder")
                  .font(.body)
                  .foregroundColor(Color.green)
            }).buttonStyle(PlainButtonStyle())
         }
         Button(action: {
            self.appData.deleteFile(name: self.file.name)
         }, label: {
            Image(systemName: "trash")
               .font(.body)
               .foregroundColor(Color.red)
         }).buttonStyle(PlainButtonStyle())
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(AppData())
    }
}
