
import SwiftUI

struct FileDetailsView: View {
   @EnvironmentObject var appData: AppData
   let file: UUID

   var body: some View {
      let values = appData.getDetails(file: file)
      return VStack {
         HStack {
            Text("Extension:")
               .frame(width: 80, alignment: .trailing)
            Text(values.0)
               .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
         }
         HStack {
            Text("Size:")
               .frame(width: 80, alignment: .trailing)
            Text(values.1)
               .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
         }
         HStack {
            Text("Date:")
               .frame(width: 80, alignment: .trailing)
            Text(values.2)
               .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
         }
         Spacer()
      }.padding()
      .navigationBarTitle("Details")
   }
}

struct FileDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        FileDetailsView(file: UUID()).environmentObject(AppData())
    }
}
