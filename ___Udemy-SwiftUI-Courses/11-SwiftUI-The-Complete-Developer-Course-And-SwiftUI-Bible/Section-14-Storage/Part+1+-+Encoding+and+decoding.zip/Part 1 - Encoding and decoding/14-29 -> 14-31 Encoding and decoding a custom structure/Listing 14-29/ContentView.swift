
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var openSheet: Bool = false

   var body: some View {
      NavigationView {
         VStack(alignment: .leading) {
            Text("Title: \(appData.bookInFile.title)")
            Text("Author: \(appData.bookInFile.author)")
            Text("Year: \(appData.bookInFile.year)")
            Image(uiImage: appData.bookInFile.cover)
               .resizable()
               .scaledToFit()
         }.padding()
         .frame(minWidth: 0, maxWidth: .infinity)
         .navigationBarTitle("Book")
         .navigationBarItems(trailing: Button("Change") {
            self.openSheet = true
         })
         .sheet(isPresented: $openSheet) {
            InsertBookView(openSheet: self.$openSheet)
               .environmentObject(self.appData)
         }
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(AppData())
    }
}
