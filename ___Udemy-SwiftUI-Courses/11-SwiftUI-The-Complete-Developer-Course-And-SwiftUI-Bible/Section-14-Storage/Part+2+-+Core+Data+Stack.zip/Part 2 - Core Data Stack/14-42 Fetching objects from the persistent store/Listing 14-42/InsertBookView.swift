
import SwiftUI
import CoreData

struct InsertBookView: View {
   @Environment(\.managedObjectContext) var dbContext
   @Environment(\.presentationMode) var presentation
   @State private var inputTitle: String = ""
   @State private var inputYear: String = ""

   var body: some View {
      VStack(spacing: 12) {
         HStack {
            Text("Title:")
            TextField("Insert Title", text: $inputTitle)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Text("Year:")
            TextField("Insert Year", text: $inputYear)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Text("Author:")
            Text("Undefined")
         }.frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
         Spacer()
      }.padding()
      .navigationBarTitle("Add Book")
      .navigationBarItems(trailing: Button("Save") {
         let newTitle = self.inputTitle.trimmingCharacters(in: .whitespaces)
         let newYear = Int32(self.inputYear)
         if !newTitle.isEmpty && newYear != nil {
            let newBook = Books(context: self.dbContext)
            newBook.title = newTitle
            newBook.year = newYear!
            newBook.author = nil
            newBook.cover = UIImage(named: "bookcover")?.pngData()
            newBook.thumbnail = UIImage(named: "bookthumbnail")?.pngData()
            do {
               try self.dbContext.save()
               self.presentation.wrappedValue.dismiss()
            } catch {
               print("Error saving record")
            }
         }
      })
   }
}
struct InsertBookView_Previews: PreviewProvider {
    static var previews: some View {
        InsertBookView()
    }
}
