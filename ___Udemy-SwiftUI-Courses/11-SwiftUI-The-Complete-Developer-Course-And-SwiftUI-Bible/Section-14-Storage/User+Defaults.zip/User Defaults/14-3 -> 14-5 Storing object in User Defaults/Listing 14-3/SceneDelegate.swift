
import UIKit
import SwiftUI

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
   var window: UIWindow?

   func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let contentView = ContentView()
         .environmentObject(delegate.myData)

      if let windowScene = scene as? UIWindowScene {
         let window = UIWindow(windowScene: windowScene)
         window.rootViewController = UIHostingController(rootView: contentView)
         self.window = window
         window.makeKeyAndVisible()
      }
   }
   func sceneWillResignActive(_ scene: UIScene) {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let appData = delegate.myData
      appData?.lastDate = Date()
   }
   func sceneDidBecomeActive(_ scene: UIScene) {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let appData = delegate.myData
      if let date = UserDefaults.standard.object(forKey: "lastDate") as? Date {
         appData?.lastDate = date
      } else {
         appData?.lastDate = Date()
      }
   }
}
