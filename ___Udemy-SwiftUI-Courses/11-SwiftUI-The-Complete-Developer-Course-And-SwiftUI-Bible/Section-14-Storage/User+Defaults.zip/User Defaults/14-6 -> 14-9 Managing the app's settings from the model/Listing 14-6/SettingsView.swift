
import SwiftUI

struct SettingsView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      Form {
         Section {
            HStack(alignment: .top) {
               Text("Corner Radius")
                  .padding(.top, 6)
               VStack {
                  Slider(value: self.$appData.cornerSize, in: 0...30)
                  Image("book1")
                     .resizable()
                     .scaledToFit()
                     .cornerRadius(self.appData.cornerSize)
                     .frame(width: 80, height: 100)
               }
            }
         }
         Section {
            List {
               Toggle("Show Picture", isOn: self.$appData.showCover)
               Toggle("Show Year", isOn: self.$appData.showYear)
            }
         }
      }
      .navigationBarTitle("Settings")
   }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView().environmentObject(AppData())
    }
}
