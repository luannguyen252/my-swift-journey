
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      NavigationView {
         List(appData.userData) { book in
            HStack(alignment: .top) {
               if self.appData.showCover {
                  Image(book.cover)
                     .resizable()
                     .aspectRatio(contentMode: .fit)
                     .cornerRadius(self.appData.cornerSize)
                     .frame(width: 80, height: 100)
               }
               VStack(alignment: .leading, spacing: 2) {
                  Text(book.title).bold()
                  Text(book.author)
                  if self.appData.showYear {
                     Text(book.year).font(.caption)
                  }
               }.padding(.top, 5)
               Spacer()
            }
         }
         .navigationBarTitle("Books")
         .navigationBarItems(trailing: NavigationLink("🛠", destination: SettingsView()))
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(AppData())
    }
}
