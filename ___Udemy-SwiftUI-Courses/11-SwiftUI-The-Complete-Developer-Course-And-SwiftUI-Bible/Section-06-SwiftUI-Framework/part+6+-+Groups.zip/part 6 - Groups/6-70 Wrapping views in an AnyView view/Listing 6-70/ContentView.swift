
import SwiftUI

struct ContentView: View {
   var body: some View {
      getView()
   }
   func getView() -> AnyView {
      let device = UIDevice.current.userInterfaceIdiom
      var myView: AnyView!
        
      if device == .phone {
         myView = AnyView(Text("iPhone"))
      } else {
         myView = AnyView(Image(systemName: "keyboard"))
      }
      return myView
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
