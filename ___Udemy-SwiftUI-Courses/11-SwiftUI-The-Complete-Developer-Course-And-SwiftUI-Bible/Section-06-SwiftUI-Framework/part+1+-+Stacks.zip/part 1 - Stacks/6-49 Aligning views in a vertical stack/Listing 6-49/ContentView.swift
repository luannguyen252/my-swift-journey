
import SwiftUI

struct ContentView: View {
   var body: some View {
      VStack(alignment: .leading) {
         Text("City")
         Text("New York")
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
