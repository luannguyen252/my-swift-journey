
import SwiftUI

struct ContentView: View {
   @State private var name: String = ""
   @State private var openAlert: Bool = false

   var body: some View {
      VStack(spacing: 10) {
         TextField("Insert your Name", text: $name)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         HStack {
            Spacer()
            Button("Save") {
               if self.name != "" {
                  self.name = ""
               } else {
                  self.openAlert = true
               }
            }
         }
         Spacer()
      }.padding()
      .font(.title)
      .alert(isPresented: $openAlert) {
         Alert(title: Text("Error"), message: Text("Insert your name"), dismissButton: .cancel())
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
