
import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
   func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
      return true
   }
   func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
      return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
   }
   override func buildMenu(with builder: UIMenuBuilder) {
      if builder.system == .main {
         let mymenu = UIMenu(title: "Selection", image: nil, identifier: UIMenu.Identifier("com.formasterminds.test.selection"), children: [])
         builder.insertSibling(mymenu, beforeMenu: .format)
      } else {
         return
      }
   }
}
