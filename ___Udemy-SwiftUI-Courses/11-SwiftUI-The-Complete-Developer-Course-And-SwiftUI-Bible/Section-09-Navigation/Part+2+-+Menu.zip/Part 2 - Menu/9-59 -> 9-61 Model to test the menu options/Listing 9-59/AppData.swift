
import SwiftUI

class AppData: ObservableObject {
   @Published var selectedCity: Bool = false
   @Published var selectedCountry: Bool = false
}
