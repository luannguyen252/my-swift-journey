
import SwiftUI

struct SettingsView: View {
   var body: some View {
      VStack {
         Text("Sheet")
            .font(.largeTitle)
         Spacer()
      }.padding()
   }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
