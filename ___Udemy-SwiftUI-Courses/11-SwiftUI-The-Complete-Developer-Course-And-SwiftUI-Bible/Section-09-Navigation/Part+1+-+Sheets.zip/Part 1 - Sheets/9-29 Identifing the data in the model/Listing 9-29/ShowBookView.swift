
import SwiftUI

struct ShowBookView: View {
   @Environment(\.presentationMode) var presentation
   let book: BookViewModel

   var body: some View {
      VStack {
         Button("X") {
            self.presentation.wrappedValue.dismiss()
         }.frame(minWidth: 0, maxWidth: .infinity, alignment: .trailing)
         Text(book.header)
         Spacer()
      }.padding()
      .font(.title)
   }
}
struct ShowBookView_Previews: PreviewProvider {
   static var previews: some View {
      ShowBookView(book: BookViewModel(book: Book(title: "Test", author: "Author")))
   }
}
