
import SwiftUI

struct ContentView: View {
   @State private var openSheet: Bool = false

   var body: some View {
      VStack(spacing: 10) {
         Button("Open Action Sheet") {
            self.openSheet = true
         }
         Spacer()
      }.padding()
      .font(.title)
      .actionSheet(isPresented: $openSheet) {
         ActionSheet(title: Text("Email"), message: Text("What do you want to do with the message?"), buttons: [
            .default(Text("Move to Inbox")),
            .destructive(Text("Delete")),
            .cancel()
         ])
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
