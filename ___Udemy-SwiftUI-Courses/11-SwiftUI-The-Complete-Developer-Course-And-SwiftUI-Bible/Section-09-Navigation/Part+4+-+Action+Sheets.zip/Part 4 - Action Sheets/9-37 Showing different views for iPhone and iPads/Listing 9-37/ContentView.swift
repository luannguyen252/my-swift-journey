
import SwiftUI

struct ContentView: View {
   @State private var openSheet: Bool = false
   @State private var openAlert: Bool = false
   @State private var message: String = "No Message"

   var body: some View {
      VStack(spacing: 10) {
         Text(message)
            Button("Open View") {
               if UIDevice.current.userInterfaceIdiom == .pad {
                  self.openAlert = true
               } else {
                  self.openSheet = true
               }
            }
            Spacer()
         }.padding()
         .font(.title)
         .actionSheet(isPresented: $openSheet) {
            ActionSheet(title: Text("Email"),
               message: Text("What do you want to do with the message?"),
               buttons: [
                  .default(Text("Move to Inbox")) {
                     self.message = "Message Moved"
                  }, .cancel() ])
         }
         .alert(isPresented: $openAlert) {
            Alert(title: Text("Email"),
               message: Text("What do you want to do with the message?"),
               primaryButton: .default(Text("Move to Inbox")) {
                  self.message = "Message Moved"
               },
               secondaryButton: .cancel())
         }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
