
import SwiftUI

struct ContentView: View {
   @State private var setColor: Bool = true

   var body: some View {
      NavigationView {
         VStack {
            Text("Hello World")
               .foregroundColor(setColor ? Color.black : Color.green)
            Spacer()
         }.padding()
         .navigationBarTitle("Home Screen")
         .navigationBarItems(trailing: Button("Change Color") {
            self.setColor.toggle()
         })
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
