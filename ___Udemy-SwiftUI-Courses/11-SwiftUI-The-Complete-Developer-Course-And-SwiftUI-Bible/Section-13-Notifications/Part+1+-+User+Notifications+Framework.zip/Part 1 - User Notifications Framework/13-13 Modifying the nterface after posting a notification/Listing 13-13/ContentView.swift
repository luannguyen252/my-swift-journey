
import SwiftUI
import UserNotifications

struct ContentView: View {
   @State private var inputMessage: String = ""
   @State private var isButtonEnabled: Bool = false

   var body: some View {
      VStack(spacing: 13) {
         HStack {
            Text("Message:")
            TextField("Insert Message", text: $inputMessage)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Spacer()
            Button("Save Notification") {
               let message = self.inputMessage.trimmingCharacters(in: .whitespaces)
               if !message.isEmpty {
                  self.postNotification()
                  self.inputMessage = ""
               }
            }.disabled(!isButtonEnabled)
         }
         Spacer()
      }.padding()
      .onAppear(perform: {
         self.getAuthorization()
      })
   }
   func getAuthorization() {
      let center = UNUserNotificationCenter.current()
      center.getNotificationSettings(completionHandler: { settings in
         if settings.authorizationStatus == .authorized {
            self.isButtonEnabled = true
         } else {
            center.requestAuthorization(options: [.alert, .sound], completionHandler: { granted, error in
               if granted && error == nil {
                  self.isButtonEnabled = true
               } else {
                  self.isButtonEnabled = false
               }
            })
         }
      })
   }
   func postNotification() {
      let content = UNMutableNotificationContent()
      content.title = "Reminder"
      content.body = self.inputMessage
      content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "alarm.mp3"))
   
      let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 30, repeats: false)
      let id = "reminder-\(UUID())"
      let request = UNNotificationRequest(identifier: id, content: content, trigger: trigger)
   
      let center = UNUserNotificationCenter.current()
      center.add(request, withCompletionHandler: { error in
         let main = OperationQueue.main
         main.addOperation {
            self.isButtonEnabled = false
         }
      })
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
