
import SwiftUI

struct Book {
   var title: String
}
struct BookViewModel: Identifiable {
   var id = UUID()
   var book: Book
}
class AppData: ObservableObject {
   @Published var userData: [BookViewModel] = []

   let publisher = NotificationCenter.Publisher(center: .default, name: Notification.Name("Update Data"))
      .receive(on: RunLoop.main)

   func addBook(book: Book) {
      userData.append(BookViewModel(book: book))

      let center = NotificationCenter.default
      let notification = Notification(name: Notification.Name("Update Data"), object: userData.count, userInfo: nil)
      center.post(notification)
   }
}
