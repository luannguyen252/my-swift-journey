
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var total: Int = 0

   var body: some View {
      NavigationView {
         VStack {
            HStack {
               Text("Total Books:")
               Text("\(total)")
                  .font(.largeTitle)
            }
            Spacer()
         }.padding()
         .navigationBarTitle("Books")
         .navigationBarItems(trailing: NavigationLink("Add Book", destination: AddBook()))
      }
      .onReceive(appData.publisher, perform: { notification in
         if let value = notification.object as? Int {
            self.total = value
         }
      })
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
