
import UIKit
import SwiftUI
import UserNotifications

class SceneDelegate: UIResponder, UIWindowSceneDelegate, UNUserNotificationCenterDelegate {
   var window: UIWindow?

   func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
      let contentView = ContentView()
      if let windowScene = scene as? UIWindowScene {
         let window = UIWindow(windowScene: windowScene)
         window.rootViewController = UIHostingController(rootView: contentView)
         self.window = window
         window.makeKeyAndVisible()
      }
      let center = UNUserNotificationCenter.current()
      center.delegate = self
   }
   func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
      let identifier = response.actionIdentifier
      if identifier == "deleteButton" {
         print("Delete Message")
      } else if identifier == "inputField" {
         print("Send: \((response as! UNTextInputNotificationResponse).userText)")
      }
      completionHandler()
   }
}
