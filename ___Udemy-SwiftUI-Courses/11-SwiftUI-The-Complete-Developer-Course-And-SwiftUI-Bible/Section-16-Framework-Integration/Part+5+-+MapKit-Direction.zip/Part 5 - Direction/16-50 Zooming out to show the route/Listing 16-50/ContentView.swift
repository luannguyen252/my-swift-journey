
import SwiftUI

struct ContentView: View {
   var map = MapView()

   var body: some View {
      VStack {
         HStack {
            Spacer()
            Button("Home") {
               self.map.showHome()
            }
         }.padding()
         map
      }
   }
}
