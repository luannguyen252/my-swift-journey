
import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
   var map = MKMapView()

   func makeUIView(context: Context) -> MKMapView {
      map.mapType = .standard
      map.delegate = context.coordinator
      return map
   }
   func updateUIView(_ uiView: MKMapView, context: Context) {}
    
   func showHome() {
      let coordOrigin = CLLocationCoordinate2D(latitude: 40.7637825011971, longitude: -73.9731328627541)
      let placeOrigin = MKPlacemark(coordinate: coordOrigin)
      let origin = MKMapItem(placemark: placeOrigin)

      let coordDestination = CLLocationCoordinate2D(latitude: 40.7523809365088, longitude: -73.9778321046893)
      let placeDestination = MKPlacemark(coordinate: coordDestination)
      let destination = MKMapItem(placemark: placeDestination)
          
      let region = MKCoordinateRegion(center: coordOrigin, latitudinalMeters: 2000, longitudinalMeters: 2000)
      map.setRegion(region, animated: false)

      let request = MKDirections.Request()
      request.source = origin
      request.destination = destination
      request.requestsAlternateRoutes = false
             
      let directions = MKDirections(request: request)
      directions.calculate(completionHandler: { (results, error) in
         if let routes = results?.routes {
            let route = routes.first!
            self.map.addOverlay(route.polyline, level: .aboveRoads)
         }
      })
   }
   func makeCoordinator() -> MapViewCoordinator {
      return MapViewCoordinator()
   }
}
class MapViewCoordinator: NSObject, MKMapViewDelegate {
   func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
      let render = MKPolylineRenderer(overlay: overlay)
      render.strokeColor = UIColor.red
      return render
   }
}
