
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      VStack {
         List {
            ForEach(self.appData.listOfPosts) { post in
               VStack(alignment: .leading) {
                  Text(post.title).bold()
                  Text(post.body)
               }.padding(5)
            }
         }
      }.padding()
   }
}
