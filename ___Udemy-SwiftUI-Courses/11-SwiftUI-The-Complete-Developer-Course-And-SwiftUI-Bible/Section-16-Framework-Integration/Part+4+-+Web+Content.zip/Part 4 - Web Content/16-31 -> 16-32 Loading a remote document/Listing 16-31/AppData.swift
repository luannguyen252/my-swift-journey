
import SwiftUI
import Combine

class AppData: ObservableObject {
   @Published var webContent: String = ""
   @Published var buttonDisabled: Bool = false

   var publisherWeb: AnyCancellable?

   func loadWeb() {
      self.buttonDisabled = true

      let webURL = URL(string: "https://www.yahoo.com")
      let request = URLRequest(url: webURL!)

      let session = URLSession.shared
      publisherWeb = session.dataTaskPublisher(for: request)
         .tryMap({ data, response -> Data? in
            if let resp = response as? HTTPURLResponse {
               if resp.statusCode == 200 {
                  return data
               }
            }
            return nil
         })
         .assertNoFailure()
         .receive(on: RunLoop.main)
         .sink(receiveValue: { data in
            if let webData = data {
               if let content = String(data: webData, encoding: String.Encoding.ascii) {
                  self.webContent = content
                  self.buttonDisabled = false
                  print(content)
               }
            }
         })
   }
}
