
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      VStack {
         Button("Load Web") {
            self.appData.loadWeb()
         }.disabled(self.appData.buttonDisabled)
            Text("Total Characters: \(self.appData.webContent.count)")
               .padding()
            Spacer()
      }.padding()
   }
}
