
import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
   func makeUIView(context: Context) -> MKMapView {
      let map = MKMapView()
      map.mapType = .standard
      map.isRotateEnabled = false
      map.delegate = context.coordinator
        
      let location = CLLocation(latitude: 40.7637825011971, longitude: -73.9731328627541)
      let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 2000, longitudinalMeters: 2000)
      map.setRegion(region, animated: false)

      let annotation = MyAnnotation(coordinate: location.coordinate)
      annotation.title = "Apple Store"
      annotation.subtitle = "Think Different"
      map.addAnnotation(annotation)

      return map
   }
   func updateUIView(_ uiView: MKMapView, context: Context) {}
    
   func makeCoordinator() -> MapViewCoordinator {
      return MapViewCoordinator()
   }
}
class MapViewCoordinator: NSObject, MKMapViewDelegate {
   func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
      if let temp = annotation as? MyAnnotation {
         var view = mapView.dequeueReusableAnnotationView(withIdentifier: "Pins") as? MKMarkerAnnotationView
         if view == nil {
            view = MKMarkerAnnotationView(annotation: temp, reuseIdentifier: "Pins")
            view?.glyphText = "Place"
            view?.markerTintColor = UIColor.blue
            view?.titleVisibility = .hidden
         } else {
            view?.annotation = annotation
         }
         return view
      }
      return nil
   }
}
