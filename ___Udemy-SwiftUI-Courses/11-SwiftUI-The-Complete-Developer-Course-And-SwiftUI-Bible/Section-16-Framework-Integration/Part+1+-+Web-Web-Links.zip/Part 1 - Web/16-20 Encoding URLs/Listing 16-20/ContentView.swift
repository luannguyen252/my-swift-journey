
import SwiftUI

struct ContentView: View {
   @State private var searchURL: String = ""

   var body: some View {
      VStack {
         HStack {
            TextField("Insert URL", text: $searchURL)
               .textFieldStyle(RoundedBorderTextFieldStyle())
               .autocapitalization(.none)
               .disableAutocorrection(true)
            Button("Open Web") {
               let app = UIApplication.shared
               if let scene = app.connectedScenes.first {
                  let dataURL = self.searchURL.data(using: String.Encoding.utf8, allowLossyConversion: false)
                  if let webURL = URL(dataRepresentation: dataURL!, relativeTo: nil, isAbsolute: true) {
                     scene.open(webURL, options: nil, completionHandler: nil)
                  }
               }
            }
         }
         Spacer()
      }.padding()
   }
}
