
import SwiftUI

class ContentData: ObservableObject {
   @Published var inputText: String = ""
   @Published var selectedText: Int = 0 {
      didSet {
         self.inputText = listTexts[self.selectedText]
      }
   }
   let listTexts: [String] = [
      "This is the first text",
      "This is the second text",
      "This is the third text"
   ]
   init() {
      self.inputText = listTexts[self.selectedText]
   }
}
struct ContentView: View {
   @ObservedObject var contentData = ContentData()

   var body: some View {
      VStack {
         Picker("", selection: $contentData.selectedText) {
            Text("First").tag(0)
            Text("Second").tag(1)
            Text("Third").tag(2)
         }.pickerStyle(SegmentedPickerStyle())

         TextView(input: $contentData.inputText)
      }.padding()
   }
}
