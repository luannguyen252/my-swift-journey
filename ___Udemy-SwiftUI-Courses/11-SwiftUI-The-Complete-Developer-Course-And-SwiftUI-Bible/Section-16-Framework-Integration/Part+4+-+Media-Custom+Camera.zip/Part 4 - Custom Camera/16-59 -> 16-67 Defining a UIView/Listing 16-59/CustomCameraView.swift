
import SwiftUI

struct CustomCameraView: View {
   @Binding var openCamera: Bool
   @Binding var picture: UIImage?
   var customView: CustomView!

   init(openCamera: Binding<Bool>, picture: Binding<UIImage?>) {
      self._openCamera = openCamera
      self._picture = picture
      customView = CustomView(openCamera: openCamera, picture: picture)
   }
   var body: some View {
      ZStack {
         customView
            .onAppear(perform: {
               self.customView.getAuthorization()
            })
         VStack {
            Spacer()
            HStack {
               Button("Cancel") {
                  self.openCamera = false
               }
               Spacer()
               Button("Take Picture") {
                  self.customView.takePicture()
               }
            }.padding()
            .frame(height: 80)
            .background(Color(red: 0.9, green: 0.9, blue: 0.9, opacity: 0.8))
         }
      }
      .edgesIgnoringSafeArea(.all)
      .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
      .navigationBarTitle("")
      .navigationBarHidden(true)
   }
}
struct CustomCameraView_Previews: PreviewProvider {
   static var previews: some View {
      CustomCameraView(openCamera: .constant(false), picture: .constant(nil))
   }
}
