
import SwiftUI

struct ImagePicker: UIViewControllerRepresentable {
   @Binding var showAlert: Bool
   @Binding var openImagePicker: Bool
   @Binding var picture: UIImage?

   func makeUIViewController(context: Context) -> UIImagePickerController {
      let mediaPicker = UIImagePickerController()
      mediaPicker.delegate = context.coordinator
      if UIImagePickerController.isSourceTypeAvailable(.camera) {
         mediaPicker.sourceType = .camera
      } else {
         print("The media is not available")
      }
      return mediaPicker
   }
   func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
   func makeCoordinator() -> ImagePickerCoordinator {
      ImagePickerCoordinator(alert: $showAlert, open: $openImagePicker, picture: $picture)
   }
}
class ImagePickerCoordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
   var showAlert: Binding<Bool>
   var openImagePicker: Binding<Bool>
   var picture: Binding<UIImage?>

   init(alert: Binding<Bool>, open: Binding<Bool>, picture: Binding<UIImage?>) {
      self.showAlert = alert
      self.openImagePicker = open
      self.picture = picture
   }
   func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
      if let newpicture = info[.originalImage] as? UIImage {
         self.picture.wrappedValue = newpicture
         UIImageWriteToSavedPhotosAlbum(newpicture, self, #selector(confirmImage(image:didFinishSavingWithError:contextInfo:)), nil)
      }
      self.openImagePicker.wrappedValue = false
   }
   @objc func confirmImage(image: UIImage, didFinishSavingWithError error: NSError?, contextInfo: UnsafeRawPointer) {
      if error == nil {
         self.showAlert.wrappedValue = true
      } else {
         print("Error")
      }
   }
}
