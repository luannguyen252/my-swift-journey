
import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
   func makeUIView(context: Context) -> MKMapView {
      let map = MKMapView()
      map.mapType = .satellite
      map.isRotateEnabled = false
        
      let location = CLLocation(latitude: 40.7637825011971, longitude: -73.9731328627541)
      let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 2000, longitudinalMeters: 2000)
      map.setRegion(region, animated: false)

      return map
   }
   func updateUIView(_ uiView: MKMapView, context: Context) {}
}
