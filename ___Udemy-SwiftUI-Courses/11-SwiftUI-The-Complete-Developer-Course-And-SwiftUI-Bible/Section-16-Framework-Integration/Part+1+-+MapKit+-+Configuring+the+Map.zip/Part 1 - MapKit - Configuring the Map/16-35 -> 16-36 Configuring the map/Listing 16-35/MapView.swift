
import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
   func makeUIView(context: Context) -> MKMapView {
      let map = MKMapView()
      map.mapType = .satellite
      map.isRotateEnabled = false
      return map
   }
   func updateUIView(_ uiView: MKMapView, context: Context) {}
}
