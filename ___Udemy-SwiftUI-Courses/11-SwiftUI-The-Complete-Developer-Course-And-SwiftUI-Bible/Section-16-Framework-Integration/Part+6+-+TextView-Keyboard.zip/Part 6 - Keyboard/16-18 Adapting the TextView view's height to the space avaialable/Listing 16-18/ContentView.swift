
import SwiftUI

class ContentData: ObservableObject {
   @Published var textViewHeight: CGFloat = .infinity

   let openPublisher = NotificationCenter.Publisher(center: .default, name: UIWindow.keyboardWillShowNotification)
      .map({ notification -> CGFloat in
         if let info = notification.userInfo {
            let value = info[UIWindow.keyboardFrameEndUserInfoKey] as! NSValue
            let height = value.cgRectValue.height
            return height
         } else {
            return .infinity
         }
      })
      .receive(on: RunLoop.main)
   let closePublisher = NotificationCenter.Publisher(center: .default, name: UIWindow.keyboardDidHideNotification)
      .receive(on: RunLoop.main)
}
struct ContentView: View {
   @ObservedObject var contentData = ContentData()

   var body: some View {
      VStack {
         TextView()
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: self.contentData.textViewHeight)
            .animation(.easeInOut)
         Spacer()
      }.padding(10)
      .onReceive(contentData.openPublisher, perform: { keyboardHeight in
         let screenHeight = UIScreen.main.bounds.height
         self.contentData.textViewHeight = screenHeight - keyboardHeight - 50
      })
      .onReceive(contentData.closePublisher, perform: { _ in
         self.contentData.textViewHeight = .infinity
      })
   }
}
