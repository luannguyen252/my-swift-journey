
import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
   var map = MKMapView()
   var locationManager: CLLocationManager!

   init() {
      locationManager = CLLocationManager()
      locationManager.requestWhenInUseAuthorization()
   }
   func makeUIView(context: Context) -> MKMapView {
      map.mapType = .standard
      map.showsUserLocation = true
      map.userLocation.title = "You are here"
      return map
   }
   func updateUIView(_ uiView: MKMapView, context: Context) {}
    
   func showHome() {
      let location = map.userLocation
      let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 2000, longitudinalMeters: 2000)
      map.setRegion(region, animated: true)

      let request = MKLocalSearch.Request()
      request.naturalLanguageQuery = "Pizza"
      request.region = map.region
          
      let search = MKLocalSearch(request: request)
      search.start(completionHandler: { (results, error) in
         if let items = results?.mapItems {
            self.map.removeAnnotations(self.map.annotations)
            for item in items {
               if let coordinates = item.placemark.location?.coordinate {
                  let annotation = MKPointAnnotation()
                  annotation.coordinate = coordinates
                  annotation.title = item.name
                  annotation.subtitle = item.phoneNumber
                  self.map.addAnnotation(annotation)
               }
            }
         }
      })
   }
}
