
import SwiftUI

struct TextView: UIViewRepresentable {
   @Binding var input: String

   func makeUIView(context: Context) -> UITextView {
      let view = UITextView()
      view.backgroundColor = UIColor.yellow
      view.font = UIFont.systemFont(ofSize: 17)
      view.textContainerInset = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
      view.text = input
      view.delegate = context.coordinator
      return view
   }
   func updateUIView(_ uiView: UITextView, context: Context) {}

   func makeCoordinator() -> CoordinatorTextView {
         CoordinatorTextView(representable: self)
      }
    
}
class CoordinatorTextView: NSObject, UITextViewDelegate {
   var representable: TextView
      init(representable: TextView) {
         self.representable = representable
      }
      func textViewDidChange(_ textView: UITextView) {
         if let text = textView.text {
            self.representable.input = text
         }
      }
   }
