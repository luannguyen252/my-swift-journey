
import UIKit

class FoodCell: UICollectionViewCell {
   var picture: UIImageView = UIImageView(frame: CGRect.zero)

   override init(frame: CGRect) {
      super.init(frame: frame)
      picture.contentMode = .scaleAspectFit
      picture.translatesAutoresizingMaskIntoConstraints = false
      contentView.addSubview(picture)

      selectedBackgroundView = UIView()
      selectedBackgroundView?.backgroundColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 1)
        
      let constraint1 = picture.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 0)
      let constraint2 = picture.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: 0)
      let constraint3 = picture.topAnchor.constraint(equalTo: self.topAnchor, constant: 0)
      let constraint4 = picture.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0)
      self.addConstraints([constraint1, constraint2, constraint3, constraint4])
   }
   required init?(coder: NSCoder) {
      fatalError("Error")
   }
}
