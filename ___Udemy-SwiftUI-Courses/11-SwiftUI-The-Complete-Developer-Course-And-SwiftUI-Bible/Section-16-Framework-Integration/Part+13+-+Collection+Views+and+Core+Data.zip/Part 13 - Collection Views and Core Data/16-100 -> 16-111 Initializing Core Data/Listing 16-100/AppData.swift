
import SwiftUI
import CoreData

enum Sections {
   case main
}
class AppData: NSObject, ObservableObject, NSFetchedResultsControllerDelegate {
   @Published var selectedItem: Int?

   var collectionView: UICollectionView!
   var dataSource: UICollectionViewDiffableDataSource<Sections, Foods>!
   var fetchedController: NSFetchedResultsController<Foods>!
   var dbContext: NSManagedObjectContext!

   override init() {
      super.init()
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      dbContext = delegate.persistentContainer.viewContext

      let layout = UICollectionViewFlowLayout()
      layout.scrollDirection = .vertical
      layout.itemSize = CGSize(width: 150, height: 100)
      layout.sectionInset = UIEdgeInsets(top: 20, left: 5, bottom: 20, right: 5)

      collectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
      collectionView.backgroundColor = .white
      collectionView.register(FoodCell.self, forCellWithReuseIdentifier: "FoodCell")

      dataSource = UICollectionViewDiffableDataSource<Sections, Foods>(collectionView: collectionView) { collectionView, indexPath, food in
         let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FoodCell", for: indexPath) as! FoodCell
         if let data = food.picture {
            cell.picture.image = UIImage(data: data, scale: UIScreen.main.scale)
         } else {
            cell.picture.image = UIImage(named: "nothumbnail")
         }
         return cell
      }
      self.generateFetchResult()
   }
   func generateFetchResult() {
      let request: NSFetchRequest<Foods> = Foods.fetchRequest()
      let sort = NSSortDescriptor(key: "name", ascending: true)
      request.sortDescriptors = [sort]
      fetchedController = NSFetchedResultsController(fetchRequest: request, managedObjectContext: self.dbContext, sectionNameKeyPath: nil, cacheName: nil)
      fetchedController.delegate = self
      do {
         try fetchedController.performFetch()
         self.generateSnapshot()
      } catch {
         print("Error fetching")
      }
   }
    func generateSnapshot() {
       var snapshot = NSDiffableDataSourceSnapshot<Sections, Foods>()
       snapshot.appendSections([.main])
       snapshot.appendItems(self.fetchedController.fetchedObjects ?? [])
       dataSource.apply(snapshot)
    }
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
       self.generateSnapshot()
    }
    func addItem(name: String) {
       let newFood = Foods(context: self.dbContext)
       newFood.name = name
       newFood.picture = UIImage(named: "nothumbnail")?.pngData()
       do {
          try self.dbContext.save()
       } catch {
          print("Error creating Foods object")
       }
    }
    func removeItem(index: Int) {
       let path = IndexPath(item: index, section: 0)
       let food = fetchedController.object(at: path)
       self.dbContext.delete(food)
       do {
          try self.dbContext.save()
       } catch {
          print("Error deleting object")
       }
    }


}
