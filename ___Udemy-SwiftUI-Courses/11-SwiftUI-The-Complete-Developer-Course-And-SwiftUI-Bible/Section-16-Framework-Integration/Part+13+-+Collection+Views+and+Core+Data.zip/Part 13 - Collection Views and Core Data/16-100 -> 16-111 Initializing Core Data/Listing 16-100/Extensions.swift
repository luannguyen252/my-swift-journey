
import SwiftUI
import CoreData

extension Foods {
   var foodThumbnail: UIImage {
      if let pic = picture, let image = UIImage(data: pic, scale: UIScreen.main.scale) {
         return image
      } else {
         return UIImage(named: "nothumbnail")!
      }
   }
   var foodName: String {
      return name ?? "Undefined"
   }
}
