
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      NavigationView {
         VStack {
            CollectionView()
               .navigationBarTitle("Food", displayMode: .inline)
               .navigationBarItems(trailing: NavigationLink(destination: AddItem(), label: {
                  Image(systemName: "plus.circle")
                     .font(.title)
               }))
            NavigationLink(destination: ItemDetailView(), tag: appData.selectedItem ?? 0, selection: $appData.selectedItem, label: {
               EmptyView()
            })
         }
         .onAppear(perform: {
            if let paths = self.appData.collectionView.indexPathsForSelectedItems {
               for path in paths {
                  self.appData.collectionView.deselectItem(at: path, animated: true)
               }
            }
         })
      }
   }
}
