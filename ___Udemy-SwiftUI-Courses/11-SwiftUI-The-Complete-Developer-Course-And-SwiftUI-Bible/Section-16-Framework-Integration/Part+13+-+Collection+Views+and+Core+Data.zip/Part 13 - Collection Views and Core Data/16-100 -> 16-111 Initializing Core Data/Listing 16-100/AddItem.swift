
import SwiftUI

struct AddItem: View {
   @EnvironmentObject var appData: AppData
   @Environment(\.presentationMode) var presentation
   @State private var inputName: String = ""

   var body: some View {
      VStack {
         HStack {
            Text("Name: ")
            TextField("Inser Name", text: $inputName)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Spacer()
            Button("Save") {
               let text = self.inputName.trimmingCharacters(in: .whitespaces)
               if !text.isEmpty {
                  self.appData.addItem(name: text)
                  self.presentation.wrappedValue.dismiss()
               }
            }
         }
         Spacer()
      }.padding()
   }
}
