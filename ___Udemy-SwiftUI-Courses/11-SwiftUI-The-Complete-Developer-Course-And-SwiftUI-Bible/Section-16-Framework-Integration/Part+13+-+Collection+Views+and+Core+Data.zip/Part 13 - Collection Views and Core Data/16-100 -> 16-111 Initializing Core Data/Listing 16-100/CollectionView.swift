
import SwiftUI

struct CollectionView: UIViewRepresentable {
   @EnvironmentObject var appData: AppData

   func makeUIView(context: Context) -> UICollectionView {
      appData.collectionView.delegate = context.coordinator
      return appData.collectionView
   }
   func updateUIView(_ uiView: UICollectionView, context: Context) {}
    
   func makeCoordinator() -> CollectionViewCoordinator {
      return CollectionViewCoordinator(data: self.appData)
   }
}
class CollectionViewCoordinator: NSObject, UICollectionViewDelegate {
   var appData: AppData!
    
   init(data: AppData) {
      self.appData = data
   }
   func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
      let index = indexPath.item
      appData.selectedItem = index
   }
}
