
import SwiftUI

struct ItemDetailView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      let path = IndexPath(item: appData.selectedItem ?? 0, section: 0)
      let food = appData.fetchedController.object(at: path)
        
      return VStack(alignment: .center, spacing: 20) {
         Text(food.foodName)
            .font(.title)
         Image(uiImage: food.foodThumbnail)
      }.padding()
      .navigationBarItems(trailing: Button("Remove") {
         if let selected = self.appData.selectedItem {
            self.appData.removeItem(index: selected)
            self.appData.selectedItem = nil
         }
      })
   }
}
