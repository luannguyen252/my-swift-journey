
import SwiftUI

struct ContentView: View {
   var body: some View {
      NavigationView {
         List {
            Text("Hello World")
         }
         .navigationBarTitle("Test Bar")
      }
      .onAppear(perform: {
         let appearance = UINavigationBarAppearance()
         if let myfont = UIFont(name: "Horsepower-Regular", size: 50) {
            appearance.largeTitleTextAttributes = [
               NSAttributedString.Key.font: myfont
            ]
         }
         let barAppearance = UINavigationBar.appearance()
         barAppearance.standardAppearance = appearance
         barAppearance.compactAppearance = appearance
         barAppearance.scrollEdgeAppearance = appearance
      })
   }
}
