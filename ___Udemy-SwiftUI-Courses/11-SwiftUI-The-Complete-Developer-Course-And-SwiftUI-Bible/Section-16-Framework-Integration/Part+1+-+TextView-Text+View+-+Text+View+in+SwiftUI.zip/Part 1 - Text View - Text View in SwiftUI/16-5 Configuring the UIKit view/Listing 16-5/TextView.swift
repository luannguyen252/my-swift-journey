
import SwiftUI

struct TextView: UIViewRepresentable {
   func makeUIView(context: Context) -> UITextView {
      let view = UITextView()
      view.backgroundColor = UIColor.yellow
      view.font = UIFont.systemFont(ofSize: 17)
      view.textContainerInset = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
      return view
   }
   func updateUIView(_ uiView: UITextView, context: Context) {}
}
