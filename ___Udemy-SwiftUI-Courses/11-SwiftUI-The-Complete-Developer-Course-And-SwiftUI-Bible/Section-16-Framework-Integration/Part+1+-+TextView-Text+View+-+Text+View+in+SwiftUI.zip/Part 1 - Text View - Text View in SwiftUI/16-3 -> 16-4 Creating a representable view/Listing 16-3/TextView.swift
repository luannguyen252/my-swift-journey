
import SwiftUI

struct TextView: UIViewRepresentable {
   func makeUIView(context: Context) -> UITextView {
      let view = UITextView()
      return view
   }
   func updateUIView(_ uiView: UITextView, context: Context) {
   }
}
