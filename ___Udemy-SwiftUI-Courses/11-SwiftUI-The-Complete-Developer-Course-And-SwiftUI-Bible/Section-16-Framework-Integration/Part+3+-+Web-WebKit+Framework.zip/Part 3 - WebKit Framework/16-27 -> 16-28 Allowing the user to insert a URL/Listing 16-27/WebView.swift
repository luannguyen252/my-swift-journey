
import SwiftUI
import WebKit

struct WebView : UIViewRepresentable {
   @Binding var inputURL: String
   let view: WKWebView = WKWebView()

   func makeUIView(context: Context) -> WKWebView  {
      view.navigationDelegate = context.coordinator
      let request = URLRequest(url: URL(string: "https://www.google.com")!)
      self.view.load(request)
      return view
   }
   func updateUIView(_ uiView: WKWebView, context: Context) {}

   func loadWeb(loadWeb: String) {
      let dataURL = loadWeb.data(using: String.Encoding.utf8, allowLossyConversion: false)
      if let webURL = URL(dataRepresentation: dataURL!, relativeTo: nil, isAbsolute: true) {
         let request = URLRequest(url: webURL)
         view.load(request)
      }
   }
   func makeCoordinator() -> CoordinatorWebView {
      return CoordinatorWebView(input: $inputURL)
   }
}
class CoordinatorWebView: NSObject, WKNavigationDelegate {
   var inputURL: Binding<String>

   init(input: Binding<String>) {
      self.inputURL = input
   }
   func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
      if let webURL = webView.url {
         self.inputURL.wrappedValue = webURL.absoluteString
      }
   }
}
