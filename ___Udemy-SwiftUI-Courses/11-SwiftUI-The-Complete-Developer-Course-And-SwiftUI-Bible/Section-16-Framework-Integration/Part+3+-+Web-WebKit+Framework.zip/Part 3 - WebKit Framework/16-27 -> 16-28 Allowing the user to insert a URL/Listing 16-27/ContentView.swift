
import SwiftUI

class ContentData: ObservableObject {
   @Published var inputURL: String = "https://"
}
struct ContentView: View {
   @ObservedObject var contentData = ContentData()
   var webView: WebView!

   init() {
      self.webView = WebView(inputURL: $contentData.inputURL)
   }
   var body: some View {
      VStack {
         HStack {
            TextField("Insert URL", text: $contentData.inputURL)
            Button("Load") {
               let text = self.contentData.inputURL.trimmingCharacters(in: .whitespaces)
               if !text.isEmpty {
                  self.webView.loadWeb(loadWeb: text)
               }
            }
         }.padding(5)
         webView
      }
   }
}
