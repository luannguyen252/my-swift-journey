
import SwiftUI

class ContentData: ObservableObject {
   @Published var inputURL: String = "https://"
   @Published var backDisabled: Bool = true
   @Published var forwardDisabled: Bool = true
}
struct ContentView: View {
   @ObservedObject var contentData = ContentData()
   var webView: WebView!
    
   init() {
      webView = WebView(inputURL: $contentData.inputURL, backDisabled: $contentData.backDisabled, forwardDisabled: $contentData.forwardDisabled)
   }
   var body: some View {
      VStack {
         HStack {
            TextField("Insert URL", text: $contentData.inputURL)
            Button("Load") {
               let text = self.contentData.inputURL.trimmingCharacters(in: .whitespaces)
               if !text.isEmpty {
                  self.webView.loadWeb(loadWeb: text)
               }
            }
         }.padding(5)

         HStack {
            Button(action: {
               self.webView.goBack()
            }, label: {
               Image(systemName: "arrow.left.circle")
                  .font(.title)
            }).disabled(self.contentData.backDisabled)
            Button(action: {
               self.webView.goForward()
            }, label: {
               Image(systemName: "arrow.right.circle")
                  .font(.title)
            }).disabled(self.contentData.forwardDisabled)
            Spacer()
            Button(action: {
               self.webView.refresh()
            }, label: {
               Image(systemName: "arrow.clockwise.circle")
                  .font(.title)
            })
         }.padding(5)
         webView
      }
   }
}
