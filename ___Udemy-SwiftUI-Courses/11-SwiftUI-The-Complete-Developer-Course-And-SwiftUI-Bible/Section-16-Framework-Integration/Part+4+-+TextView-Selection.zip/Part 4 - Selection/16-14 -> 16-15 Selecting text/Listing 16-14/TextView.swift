
import SwiftUI

struct TextView: UIViewRepresentable {
   @Binding var selected: String

   func makeUIView(context: Context) -> UITextView {
      let view = UITextView()
      view.backgroundColor = UIColor.yellow
      view.font = UIFont.systemFont(ofSize: 17)
      view.textContainerInset = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
      view.delegate = context.coordinator
      return view
   }
   func updateUIView(_ uiView: UITextView, context: Context) {}

   func makeCoordinator() -> CoordinatorTextView {
      CoordinatorTextView(selected: $selected)
   }
}
class CoordinatorTextView: NSObject, UITextViewDelegate {
   var selected: Binding<String>

   init(selected: Binding<String>) {
      self.selected = selected
   }
   func textViewDidChangeSelection(_ textView: UITextView) {
      if let text = textView.text {
         if let range = Range(textView.selectedRange, in: text) {
            self.selected.wrappedValue = String(text[range])
         }
      }
   }
}
