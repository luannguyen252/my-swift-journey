
import SwiftUI

struct ContentView: View {
   @State private var title: String = "Default Title"
   @State private var titleInput: String = ""

   var body: some View {
      VStack(spacing: 15) {
         Text(title)
            .lineLimit(1)
            .padding()
            .background(Color.yellow)
         TextField("Insert Title", text: $titleInput, onCommit: {
            self.assignTitle()
         }).textFieldStyle(RoundedBorderTextFieldStyle())
         HStack {
            Spacer()
            Button("Save") {
               self.assignTitle()
            }
         }
         Spacer()
      }.padding()
   }
   func assignTitle() {
      self.title = self.titleInput
      self.titleInput = ""
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
