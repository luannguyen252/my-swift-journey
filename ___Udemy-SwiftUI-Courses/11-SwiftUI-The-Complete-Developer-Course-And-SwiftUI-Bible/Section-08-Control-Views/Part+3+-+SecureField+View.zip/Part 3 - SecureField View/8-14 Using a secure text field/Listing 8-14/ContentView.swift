
import SwiftUI

struct ContentView: View {
   @State private var title: String = ""

   var body: some View {
      VStack(spacing: 15) {
         Text(title)
            .lineLimit(1)
            .padding()
         SecureField("Insert Title", text: $title)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         Spacer()
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
