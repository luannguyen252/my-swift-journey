
import SwiftUI

struct ContentView: View {
   @State private var currentValue: Float = 0
   @State private var goingUp: Bool = true

   var body: some View {
      VStack {
         HStack {
            Text("\(currentValue, specifier: "%.0f")")
            Text(goingUp ? "↑" : "↓")
               .foregroundColor(goingUp ? Color.green : Color.red)
            Stepper("", onIncrement: {
               self.currentValue += 5
               self.goingUp = true
            }, onDecrement: {
               self.currentValue -= 5
               self.goingUp = false
            }).labelsHidden()
         }
         Spacer()
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
