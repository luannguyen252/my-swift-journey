
import SwiftUI

struct Book {
   var title: String
   var author: String
   var cover: String
   var year: Int
}
struct BookViewModel: Identifiable {
   var id = UUID()
   var book: Book

   var title: String {
      return book.title.capitalized
   }
   var author: String {
      return book.author.capitalized
   }
   var cover: String {
      return book.cover
   }
   var year: String {
      return String(book.year)
   }
}
class AppData: ObservableObject {
   @Published var userData: [BookViewModel] = []
 
   func addBook(book: Book) {
      userData.append(BookViewModel(book: book))
   }
   func removeBook(removeID: UUID) {
      if let index = userData.firstIndex(where: { $0.id == removeID}) {
         userData.remove(at: index)
      }
   }
}
