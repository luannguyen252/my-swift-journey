
import SwiftUI

struct Book {
   var title: String
   var author: String
   var cover: String
   var year: Int
}
struct BookViewModel: Identifiable {
   var id = UUID()
   var book: Book

   var title: String {
      return book.title.capitalized
   }
   var author: String {
      return book.author.capitalized
   }
   var cover: String {
      return book.cover
   }
   var year: String {
      return String(book.year)
   }
}
class AppData: ObservableObject {
   @Published var userData: [BookViewModel] = []
 
   func addBook(book: Book) {
      userData.append(BookViewModel(book: book))
   }
   func removeBook(removeSet: IndexSet) {
      userData.remove(atOffsets: removeSet)
   }
   func moveBook(from: IndexSet, to: Int) {
      userData.move(fromOffsets: from, toOffset: to)
   }
}
