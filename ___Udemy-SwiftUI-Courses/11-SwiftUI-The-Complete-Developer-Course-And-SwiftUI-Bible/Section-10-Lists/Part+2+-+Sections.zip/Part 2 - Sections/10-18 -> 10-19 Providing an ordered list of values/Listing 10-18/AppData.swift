
import SwiftUI

struct Book {
   var title: String
   var author: String
   var cover: String
   var year: Int
}
struct BookViewModel: Identifiable {
   var id = UUID()
   var book: Book

   var title: String {
      return book.title.capitalized
   }
   var author: String {
      return book.author.capitalized
   }
   var cover: String {
      return book.cover
   }
   var year: String {
      return String(book.year)
   }
}
class AppData: ObservableObject {
   @Published var userData: [BookViewModel] = []
 
   var orderList: [(key: String, value: [BookViewModel])] {
      let listGroup: [String: [BookViewModel]] = Dictionary(grouping: userData, by: { value in
         let index = value.title.startIndex
         let initial = value.title[index]
         return String(initial)
      })
      return listGroup.sorted(by: { $0.key < $1.key })
   }
}
