
import SwiftUI

struct ContentView: View {
   @State private var openSettings: Bool = false
   @State private var setCity: String = "Paris"

   var body: some View {
      NavigationView {
         VStack(spacing: 20) {
            Text("City: \(setCity)")
               .font(.title)
            Button("Open Settings") {
               self.openSettings = true
            }
            Spacer()
         }.padding()
         .navigationBarTitle("Main Screen")
      }
      .sheet(isPresented: $openSettings) {
         SettingsView(setCity: self.$setCity)
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
