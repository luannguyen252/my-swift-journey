
import SwiftUI

struct ContentView: View {
   @State private var setTemperature: Int = 0
   @State private var setCity: String = "Paris"
   let listCities: [String] = ["Paris", "Toronto", "Dublin"]

   var body: some View {
      NavigationView {
         Form {
            Section {
               Picker("", selection: $setTemperature) {
                  Text("Celsius").tag(0)
                  Text("Fahrenheit").tag(1)
               }.labelsHidden()
               .pickerStyle(SegmentedPickerStyle())
            }
            Section {
               Picker("", selection: $setCity) {
                  ForEach(listCities, id: \.self) { city in
                     Text(city)
                  }
               }.labelsHidden()
            }
         }.navigationBarTitle("Settings")
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
