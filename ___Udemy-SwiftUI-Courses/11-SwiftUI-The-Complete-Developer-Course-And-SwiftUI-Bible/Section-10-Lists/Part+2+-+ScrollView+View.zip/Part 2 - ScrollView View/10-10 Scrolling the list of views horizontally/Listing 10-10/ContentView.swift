
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var openSheet: Bool = false

   var body: some View {
      VStack {
         HStack {
            Spacer()
            Button("Add Book") {
               self.openSheet = true
            }
         }.padding()

         ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 0) {
               ForEach(appData.userData) { book in
                  VStack {
                     Image(book.cover)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 100)
                     Text(book.title)
                        .font(.caption)
                  }.padding(10)
                  .frame(width: 100, height: 150)
               }
            }
         }.frame(height: 150)
         Spacer()
      }.sheet(isPresented: $openSheet) {
         AddBookView().environmentObject(self.appData)
      }
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      ContentView().environmentObject(self.testingModel)
   }
   static var testingModel: AppData {
      let model = AppData()
      model.userData = [
         BookViewModel(book: Book(title: "Steve Jobs", author: "Walter Isaacson", cover: "book1", year: 2011)),
         BookViewModel(book: Book(title: "HTML5 for Masterminds", author: "J.D Gauchat", cover: "book2", year: 2017)),
         BookViewModel(book: Book(title: "The Road Ahead", author: "Bill Gates", cover: "book3", year: 1995))
      ]
      return model
   }
}
