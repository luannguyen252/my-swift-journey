
import SwiftUI

struct ContentView: View {
   @State private var selectedValue: String = "Dublin"
   let listCities: [String] = ["Paris", "Toronto", "Dublin"]

   var body: some View {
      VStack {
         Text(selectedValue)
            .font(.largeTitle)
            .padding()
         Picker("", selection: $selectedValue) {
            ForEach(listCities, id: \.self) { value in
               Text(value)
            }
         }.labelsHidden()
         Spacer()
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
