
import SwiftUI
import Combine

struct PersonalInfo: Codable {
   let name: String
   let address: String
   let city: String
}
struct FileInfo: Identifiable {
   let id: UUID = UUID()
   let name: String
   let document: MyDocument
}
class AppData: ObservableObject {
   @Published var listOfFiles: [FileInfo] = []
   var metaData: NSMetadataQuery!

   init() {
      let publisherFinish = NotificationCenter.Publisher(center: .default, name: NSNotification.Name.NSMetadataQueryDidFinishGathering)
         .receive(on: RunLoop.main)
      let subscriberFinish = Subscribers.Sink<Notification, Never>(receiveCompletion: {_ in }, receiveValue: { value in
         self.getFiles()
      })
      publisherFinish.subscribe(subscriberFinish)

      let publisherUpdate = NotificationCenter.Publisher(center: .default, name: NSNotification.Name.NSMetadataQueryDidUpdate)
         .receive(on: RunLoop.main)
      let subscriberUpdate = Subscribers.Sink<Notification, Never>(receiveCompletion: {_ in }, receiveValue: { value in
         self.updateFiles(notification: value)
      })
      publisherUpdate.subscribe(subscriberUpdate)

      self.getMetadata()
   }
   func getMetadata() {
      self.metaData = NSMetadataQuery()
      self.metaData.searchScopes = [NSMetadataQueryUbiquitousDocumentsScope]
      self.metaData.start()
   }
   func getFiles() {
      if self.metaData.resultCount > 0 {
         let files = metaData.results as! [NSMetadataItem]
         for item in files {
            let fileName = item.value(forAttribute: NSMetadataItemFSNameKey) as! String
            if !listOfFiles.contains(where: { $0.name == fileName }) {
               let fileURL = item.value(forAttribute: NSMetadataItemURLKey) as! URL
               let document = MyDocument(fileURL: fileURL)
               document.open(completionHandler: nil)
               self.listOfFiles.append(FileInfo(name: fileName, document: document))
            }
         }
         self.listOfFiles.sort(by: { $0.name < $1.name })
      }
   }
    func updateFiles(notification: Notification) {
       metaData.disableUpdates()
    
       let manager = FileManager.default
       if let modifications = notification.userInfo {
          if let removed = modifications[NSMetadataQueryUpdateRemovedItemsKey] as? [NSMetadataItem] {
             for item in removed {
                let name = item.value(forAttribute: NSMetadataItemFSNameKey) as! String
                if let index = listOfFiles.firstIndex(where: { $0.name == name }) {
                   self.listOfFiles.remove(at: index)
                }
             }
          }
          if let added = modifications[NSMetadataQueryUpdateAddedItemsKey] as? [NSMetadataItem] {
             for item in added {
                let name = item.value(forAttribute: NSMetadataItemFSNameKey) as! String
                if !listOfFiles.contains(where: { $0.name == name }) {
                   if let fileURL = manager.url(forUbiquityContainerIdentifier: nil) {
                      let iCloudURL = fileURL.appendingPathComponent("Documents/\(name)")
                      let document = MyDocument(fileURL: iCloudURL)
                      document.open(completionHandler: nil)
                      self.listOfFiles.append(FileInfo(name: name, document: document))
                   }
                }
             }
             self.listOfFiles.sort(by: { $0.name < $1.name })
          }
       }
       metaData.enableUpdates()
    }
    func createFile(name: String, info: PersonalInfo) {
       let manager = FileManager.default
       if let fileURL = manager.url(forUbiquityContainerIdentifier: nil) {
          let iCloudURL = fileURL.appendingPathComponent("Documents/\(name)")
                
          let encoder = JSONEncoder()
          if let data = try? encoder.encode(info) {
             let document = MyDocument(fileURL: iCloudURL)
             document.fileContent = data
             document.save(to: iCloudURL, for: .forCreating, completionHandler: nil)
             self.listOfFiles.append(FileInfo(name: name, document: document))
             self.listOfFiles.sort(by: { $0.name < $1.name })
          }
       }
    }
    func removeFiles(indexes: IndexSet) {
       let queue = DispatchQueue(label: "delete")
       queue.async {
          for index in indexes {
             let document = self.listOfFiles[index].document
             do {
                let manager = FileManager.default
                try manager.removeItem(atPath: document.fileURL.path)
                let main = OperationQueue.main
                main.addOperation {
                   self.listOfFiles.remove(at: index)
                }
             } catch {
                print("Error deleting file")
             }
          }
       }
    }
}
