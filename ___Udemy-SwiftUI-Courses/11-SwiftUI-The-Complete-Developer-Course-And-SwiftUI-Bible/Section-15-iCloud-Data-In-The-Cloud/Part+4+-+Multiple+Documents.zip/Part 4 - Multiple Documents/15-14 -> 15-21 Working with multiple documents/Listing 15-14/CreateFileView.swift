
import SwiftUI

struct CreateFileView: View {
   @EnvironmentObject var appData: AppData
   @Binding var openSheet: Bool

   @State private var inputFileName: String = ""
   @State private var inputName: String = ""
   @State private var inputAddress: String = ""
   @State private var inputCity: String = ""

   var body: some View {
      Form {
         Section(header: Text("File Name")) {
            TextField("Insert name and extension", text: $inputFileName)
               .textFieldStyle(RoundedBorderTextFieldStyle())
               .autocapitalization(.none)
         }
         Section(header: Text("User Info")) {
            TextField("Insert Name", text: $inputName)
               .textFieldStyle(RoundedBorderTextFieldStyle())
            TextField("Insert Address", text: $inputAddress)
               .textFieldStyle(RoundedBorderTextFieldStyle())
            TextField("Insert City", text: $inputCity)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         Section {
            HStack {
               Spacer()
               Button("Save") {
                  let fileName = self.inputFileName.trimmingCharacters(in: .whitespaces)
                  if !fileName.isEmpty && !self.appData.listOfFiles.contains(where: { $0.name == fileName }) {
                     let info = PersonalInfo(name: self.inputName, address: self.inputAddress, city: self.inputCity)
                     self.appData.createFile(name: fileName, info: info)
                     self.openSheet = false
                  }
               }.buttonStyle(BorderlessButtonStyle())
            }
         }
      }
   }
}
struct CreateFileView_Previews: PreviewProvider {
   static var previews: some View {
      CreateFileView(openSheet: .constant(false))
         .environmentObject(AppData())
   }
}
