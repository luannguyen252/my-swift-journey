
import SwiftUI

struct ShowFileView: View {
   let fileInfo: FileInfo
   var personalInfo: PersonalInfo
    
   init(info: FileInfo) {
      self.fileInfo = info
      self.personalInfo = PersonalInfo(name: "", address: "", city: "")

      let decoder = JSONDecoder()
      if let data = info.document.fileContent {
         if let documentInfo = try? decoder.decode(PersonalInfo.self, from: data) {
            self.personalInfo = documentInfo
         }
      }
   }
   var body: some View {
      VStack {
         HStack {
            Text(fileInfo.name)
            Spacer()
         }
         HStack {
            Text("Name:")
            Text(personalInfo.name)
            Spacer()
         }
         HStack {
            Text("Address:")
            Text(personalInfo.address)
            Spacer()
         }
         HStack {
            Text("City:")
            Text(personalInfo.city)
            Spacer()
         }
         Spacer()
      }.padding()
      .navigationBarTitle("File")
   }
}
struct ShowFileView_Previews: PreviewProvider {
   static var previews: some View {
      let manager = FileManager.default
      var tempURL = manager.urls(for: .documentDirectory, in: .userDomainMask).first!
      tempURL = tempURL.appendingPathComponent("temp.dat")
      return ShowFileView(info: FileInfo(name: "Test", document: MyDocument(fileURL: tempURL)))
   }
}
