
import SwiftUI
import CoreData

struct ShowCitiesView: View {
   @Environment(\.managedObjectContext) var dbContext
   @State private var openSheet: Bool = false
   let selectedCountry: Countries

   var body: some View {
      VStack {
         ListCitiesView(country: self.selectedCountry)
      }
      .navigationBarTitle(self.selectedCountry.name ?? "Undefined")
      .navigationBarItems(trailing: Button("Add City") {
         self.openSheet = true
      })
      .sheet(isPresented: $openSheet) {
         InsertCityView(openSheet: self.$openSheet, country: self.selectedCountry)
            .environment(\.managedObjectContext, self.dbContext)
      }
   }
}
struct ListCitiesView: View {
   @FetchRequest(entity: Cities.entity(), sortDescriptors: []) var listCities: FetchedResults<Cities>

   init(country: Countries) {
      self._listCities = FetchRequest(entity: Cities.entity(), sortDescriptors: [NSSortDescriptor(key: "name", ascending: true)], predicate: NSPredicate(format: "country = %@", country))
   }
   var body: some View {
      List {
         ForEach(listCities, id: \.self) { city in
            Text(city.name ?? "Undefined")
         }
      }
   }
}
struct ShowCitiesView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext

      let country = Countries(context: dbContext)
      country.name = "Test"
      return ShowCitiesView(selectedCountry: country)
         .environment(\.managedObjectContext, dbContext)
   }
}
