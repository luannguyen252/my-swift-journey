
import SwiftUI
import Combine

struct PersonalInfo: Codable {
   var name: String
   var address: String
   var city: String
}
class AppData: ObservableObject {
   @Published var userInfo: PersonalInfo

   init() {
      self.userInfo = PersonalInfo(name: "", address: "", city: "")
      self.readInfo()
        
      let publisher = NotificationCenter.Publisher(center: .default, name: NSUbiquitousKeyValueStore.didChangeExternallyNotification)
         .receive(on: RunLoop.main)
      let subscriber = Subscribers.Sink<Notification, Never>(receiveCompletion: {_ in }, receiveValue: {_ in
         self.readInfo()
      })
      publisher.subscribe(subscriber)
   }
   func readInfo() {
      let kvStorage = NSUbiquitousKeyValueStore()
      if let dataInfo = kvStorage.data(forKey: "info") {
         let decoder = JSONDecoder()
         if let info = try? decoder.decode(PersonalInfo.self, from: dataInfo) {
            userInfo = info
         }
      }
   }
   func setInfo() {
      let kvStorage = NSUbiquitousKeyValueStore()
      let encoder = JSONEncoder()
      if let data = try? encoder.encode(userInfo) {
         kvStorage.set(data, forKey: "info")
      }
   }
}
