
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var openSheet: Bool = false

   var body: some View {
      NavigationView {
         VStack {
            HStack {
               Text("Name:")
               Text(appData.userInfo.name)
               Spacer()
            }
            HStack {
               Text("Address:")
               Text(appData.userInfo.address)
               Spacer()
            }
            HStack {
               Text("City:")
               Text(appData.userInfo.city)
               Spacer()
            }
            Spacer()
         }.padding()
         .navigationBarTitle("Personal Info")
         .navigationBarItems(trailing: Button("Change") {
            self.openSheet = true
         })
         .sheet(isPresented: $openSheet) {
            InsertInfoView(openSheet: self.$openSheet)
               .environmentObject(self.appData)
         }
      }
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      ContentView().environmentObject(AppData())
   }
}
