
import SwiftUI
import Combine

struct PersonalInfo: Codable {
   var name: String
   var address: String
   var city: String
}
class AppData: ObservableObject {
   @Published var userInfo: PersonalInfo

   var document: MyDocument!
   var metaData: NSMetadataQuery!

   init() {
      self.userInfo = PersonalInfo(name: "", address: "", city: "")

      let publisherFinish = NotificationCenter.Publisher(center: .default, name: NSNotification.Name.NSMetadataQueryDidFinishGathering)
         .receive(on: RunLoop.main)
      let subscriberFinish = Subscribers.Sink<Notification, Never>(receiveCompletion: {_ in }, receiveValue: {_ in
         self.createFile()
      })
      publisherFinish.subscribe(subscriberFinish)
        
      let publisherUpdate = NotificationCenter.Publisher(center: .default, name: NSNotification.Name.NSMetadataQueryDidUpdate)
         .receive(on: RunLoop.main)
      let subscriberUpdate = Subscribers.Sink<Notification, Never>(receiveCompletion: {_ in }, receiveValue: {_ in
         self.updateFile()
      })
      publisherUpdate.subscribe(subscriberUpdate)

      self.getMetadata()
   }
   func getMetadata() {
      self.metaData = NSMetadataQuery()
      self.metaData.predicate = NSPredicate(format: "%K == %@", NSMetadataItemFSNameKey, "myfile.dat")
      self.metaData.searchScopes = [NSMetadataQueryUbiquitousDocumentsScope]
      self.metaData.start()
   }
    func createFile() {
       if self.metaData.resultCount > 0 {
          let file = metaData.result(at: 0) as! NSMetadataItem
          let fileURL = file.value(forAttribute: NSMetadataItemURLKey) as! URL
          self.document = MyDocument(fileURL: fileURL)
          self.document.open(completionHandler: { (success) in
             if success {
                let decoder = JSONDecoder()
                if let data = self.document.fileContent {
                   if let info = try? decoder.decode(PersonalInfo.self, from: data) {
                      self.userInfo = info
                   }
                }
             }
             self.document.close(completionHandler: nil)
          })
       } else {
          let manager = FileManager.default
          if let fileURL = manager.url(forUbiquityContainerIdentifier: nil) {
             let iCloudURL = fileURL.appendingPathComponent("Documents/myfile.dat")
             let encoder = JSONEncoder()
             if let data = try? encoder.encode(self.userInfo) {
                document = MyDocument(fileURL: iCloudURL)
                document.fileContent = data
                if manager.fileExists(atPath: iCloudURL.path) {
                   document.save(to: iCloudURL, for: .forOverwriting, completionHandler: nil)
                } else {
                   document.save(to: iCloudURL, for: .forCreating, completionHandler: nil)
                }
                document.close(completionHandler: nil)
             }
          }
       }
    }
    func updateFile() {
       if self.metaData.resultCount > 0 {
          document.open(completionHandler: { (success) in
             if success {
                let decoder = JSONDecoder()
                if let data = self.document.fileContent {
                   if let info = try? decoder.decode(PersonalInfo.self, from: data) {
                      self.userInfo = info
                   }
                }
             }
          })
       }
    }
    func saveFile() {
       let manager = FileManager.default
       if let fileURL = manager.url(forUbiquityContainerIdentifier: nil) {
          let iCloudURL = fileURL.appendingPathComponent("Documents/myfile.dat")
        
          let encoder = JSONEncoder()
          if let data = try? encoder.encode(self.userInfo) {
             document.fileContent = data
             document.save(to: iCloudURL, for: .forOverwriting, completionHandler: nil)
             document.close(completionHandler: nil)
          }
       }
    }
}
