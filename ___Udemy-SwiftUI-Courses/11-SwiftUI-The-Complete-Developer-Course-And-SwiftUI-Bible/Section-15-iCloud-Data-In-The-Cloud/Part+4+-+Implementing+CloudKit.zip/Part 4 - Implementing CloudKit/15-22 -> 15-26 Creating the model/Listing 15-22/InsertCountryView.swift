
import SwiftUI

struct InsertCountryView: View {
   @EnvironmentObject var appData: AppData
   @Binding var openSheet: Bool
   @State private var inputName: String = ""

   var body: some View {
      VStack {
         HStack {
            Text("Country:")
            TextField("Insert Country", text: $inputName)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Spacer()
            Button("Save") {
               let text = self.inputName.trimmingCharacters(in: .whitespaces)
               if !text.isEmpty {
                  self.appData.insertCountry(name: text)
                  self.openSheet = false
               }
            }
         }
         Spacer()
      }.padding()
   }
}
struct InsertCountryView_Previews: PreviewProvider {
   static var previews: some View {
      InsertCountryView(openSheet: .constant(false))
         .environmentObject(AppData())
   }
}
