import Foundation

var length = Measurement(value: 200, unit: UnitLength.centimeters)
var width = Measurement(value: 800, unit: UnitLength.centimeters)

var total = length + width  // 1000.0 cm
