import Foundation

let square = sqrt(4.0)
let power = pow(2.0, 2.0)
let maximum = max(square, power)

print("The maximum value is \(maximum)")  // "The maximum value is 4.0"
