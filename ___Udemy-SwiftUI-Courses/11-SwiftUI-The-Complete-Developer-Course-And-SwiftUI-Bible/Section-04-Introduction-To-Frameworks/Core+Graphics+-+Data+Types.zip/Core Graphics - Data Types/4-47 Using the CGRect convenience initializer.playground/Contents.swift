import CoreGraphics

var myrect = CGRect(x: 30, y: 20, width: 100, height: 200)

print("The origin is at \(myrect.origin.x) and \(myrect.origin.y)")
print("The size is \(myrect.size.width) by \(myrect.size.height)")
