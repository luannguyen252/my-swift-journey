import Foundation

var age = 44
var mytext = String.localizedStringWithFormat("My age is %d", age)
print(mytext)  // "My age is 44"
