import Foundation

var text = "Hello World"
var newText = text as NSString
print(newText)  // "Hello World"
