import Foundation

var text: NSString = NSString(string: "Hello")
print(text)  // "Hello"
