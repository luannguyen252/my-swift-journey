//
//  PlayersTableViewController.swift
//  NBA UIKit
//
//  Created by ZappyCode on 11/7/19.
//  Copyright © 2019 ZappyCode. All rights reserved.
//

import UIKit
import SwiftUI

class PlayersTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return players.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "playerCell", for: indexPath)

        cell.textLabel?.text = players[indexPath.row].name

        return cell
    }

    @IBSegueAction func moveToPlayerDetail(_ coder: NSCoder) -> UIViewController? {
        
        let player = players[tableView.indexPathForSelectedRow!.row]
        
        let playerDetail = PlayerDetail(player: player)
        
        return UIHostingController(coder: coder, rootView: playerDetail)
    }
}
