//
//  Movie.swift
//  BuildNetflix
//
//  Created by Nikita Thomas on 7/6/20.
//

import Foundation

struct Movie: Identifiable {
    var id: String
    var name: String
    var thumbnailURL: URL
    
    var categories: [String] 
}
