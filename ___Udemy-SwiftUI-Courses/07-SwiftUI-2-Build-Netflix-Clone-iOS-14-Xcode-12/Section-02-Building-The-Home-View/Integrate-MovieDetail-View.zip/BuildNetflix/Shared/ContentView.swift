//
//  ContentView.swift
//  Shared
//
//  Created by Nikita Thomas on 7/6/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!").padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
