//
//  SearchView.swift
//  iOS
//
//  Created by Nikita Thomas on 8/3/20.
//

import SwiftUI

struct SearchView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView()
    }
}
