import XCTest

import VideoPlayerTests

var tests = [XCTestCaseEntry]()
tests += VideoPlayerTests.allTests()
XCTMain(tests)
