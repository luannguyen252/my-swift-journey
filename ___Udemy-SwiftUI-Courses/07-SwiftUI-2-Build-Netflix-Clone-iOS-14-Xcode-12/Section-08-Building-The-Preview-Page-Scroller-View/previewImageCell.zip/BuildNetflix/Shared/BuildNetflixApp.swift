//
//  BuildNetflixApp.swift
//  Shared
//
//  Created by Nikita Thomas on 7/6/20.
//

import SwiftUI

@main
struct BuildNetflixApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
