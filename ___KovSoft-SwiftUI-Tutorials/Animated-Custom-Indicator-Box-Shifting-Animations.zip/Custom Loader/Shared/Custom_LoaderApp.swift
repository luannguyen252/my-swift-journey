//
//  Custom_LoaderApp.swift
//  Shared
//
//  Created by Balaji on 16/03/21.
//

import SwiftUI

@main
struct Custom_LoaderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
