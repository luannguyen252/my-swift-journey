//
//  Marvel_APIApp.swift
//  Shared
//
//  Created by Balaji on 14/03/21.
//

import SwiftUI

@main
struct Marvel_APIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
