//
//  Credentials.swift
//  Marvel API
//
//  Created by Balaji on 14/03/21.
//

import SwiftUI

let privateKey = "PRIVATE KEY HERE"
let publicKey = "PUBLIC KEY HERE"
