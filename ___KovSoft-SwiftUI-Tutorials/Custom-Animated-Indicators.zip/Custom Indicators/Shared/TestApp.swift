//
//  TestApp.swift
//  Shared
//
//  Created by Balaji on 12/03/21.
//

import SwiftUI

@main
struct TestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
