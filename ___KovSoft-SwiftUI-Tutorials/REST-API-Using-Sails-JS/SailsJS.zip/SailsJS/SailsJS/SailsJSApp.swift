//
//  SailsJSApp.swift
//  SailsJS
//
//  Created by Balaji on 31/08/20.
//

import SwiftUI

@main
struct SailsJSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
