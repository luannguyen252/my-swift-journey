//
//  Movie.swift
//  Movie Tracker
//
//  Created by ZappyCode on 11/4/19.
//  Copyright © 2019 ZappyCode. All rights reserved.
//

import Foundation

struct Movie: Identifiable {
    var id = UUID()
    var title = ""
    var rating = 3.0
    var seen = false
}

class MovieStorage: ObservableObject {
    @Published var movies = [Movie]()
}
