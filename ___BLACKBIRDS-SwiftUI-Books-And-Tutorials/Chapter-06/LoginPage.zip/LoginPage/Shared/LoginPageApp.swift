//File: LoginPageApp.swift
//Project: LoginPage
//Created on 13.08.20
//Visit www.BLCKBIRDS.com for more tutorials.

import SwiftUI

@main
struct LoginPageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
