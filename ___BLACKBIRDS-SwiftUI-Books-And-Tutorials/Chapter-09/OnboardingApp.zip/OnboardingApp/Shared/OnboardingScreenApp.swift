//File: OnboardingScreenApp.swift
//Project: OnboardingScreen
//Created on 27.08.20
//Visit www.BLCKBIRDS.com for more tutorials.

import SwiftUI

@main
struct OnboardingScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
