//File: ContentView.swift
//Project: OnboardingScreen
//Created on 27.08.20
//Visit www.BLCKBIRDS.com for more tutorials.

import SwiftUI

struct ContentView: View {
    
    @State var selectedTab: Tab = .meditating
    
    init() {
       UIPageControl.appearance().currentPageIndicatorTintColor = .orange
       UIPageControl.appearance().pageIndicatorTintColor = UIColor.gray.withAlphaComponent(0.5)
       }
    
    var body: some View {
        NavigationView {
            ZStack(alignment: .bottomTrailing) {
                TabView(selection: $selectedTab) {
                    ForEach(subviewData) { entry in
                        Subview(subviewModel: entry)
                            .tag(entry.tag)
                    }
                }
                    .tabViewStyle(PageTabViewStyle())
                    .navigationTitle("Calmify")
                NavigatorView(selectedTab: $selectedTab)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}


struct NavigatorView: View {
    
    @Binding var selectedTab: Tab
    
    var body: some View {
        HStack {
            Spacer()
            Button(action: {
                withAnimation {
                    switch selectedTab {
                    case .meditating:
                        selectedTab = .running
                    case .running:
                        selectedTab = .walking
                    case .walking:
                        return
                    }
                }
            }) {
                Image(systemName: "arrow.right")
                    .resizable()
                    .foregroundColor(.white)
                    .frame(width: 30, height: 30)
                    .padding()
                    .background(Color.orange)
                    .cornerRadius(30)
            }
        }
            .padding()
    }
}
