//
//  Photo_EditorApp.swift
//  Shared
//
//  Created by Andreas Schultz on 06.09.20.
//

import SwiftUI

@main
struct Photo_EditorApp: App {
    
    @StateObject var imageController = ImageController()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(imageController)
        }
    }
}
