//
//  Helper.swift
//  Photo Editor
//
//  Created by Andreas Schultz on 07.09.20.
//

import Foundation

enum FilterType {
    case Original
    case Sepia
    case Mono
    case Vibrance
    case Highlight
    case Vignette
}
