//
//  ContentView.swift
//  Shared
//
//  Created by Andreas Schultz on 08.09.20.
//

import SwiftUI
import MapKit

struct ContentView: View {
    
    @State var currentAnnotation: MKPointAnnotation?
    @State var showPhotoGrid = false
    
    @EnvironmentObject var locationManager: LocationManager
    
    var body: some View {
        NavigationView {
            ZStack(alignment: .bottomTrailing) {
                MyMap(showPhotoGrid: $showPhotoGrid, currentRegion: $locationManager.currentRegion, currentAnnotation: $currentAnnotation)
                Button(action: {
                    locationManager.goToUserLocation()
                }) {
                    LocationButtonContent()
                }
            }
                .navigationBarTitle("Long-press to drop pin", displayMode: .inline)
                .edgesIgnoringSafeArea(.all)
                .sheet(isPresented: $showPhotoGrid, content: {
                    PhotoGrid(latitudeToSearchFor: (currentAnnotation?.coordinate.latitude)!, longitudeToSearchFor: (currentAnnotation?.coordinate.longitude)!)
                })
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(LocationManager())
    }
}

struct LocationButtonContent: View {
    var body: some View {
        ZStack {
            Circle()
                .frame(width: 60, height: 60)
                .foregroundColor(.white)
            Image(systemName: "location")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 25, height: 25)
                .clipped()
                .foregroundColor(.black)
                .padding(40)
        }
    }
}
