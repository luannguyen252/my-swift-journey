//
//  LocationManager.swift
//  City Explorer
//
//  Created by Andreas Schultz on 10.09.20.
//

import MapKit
import SwiftUI

class LocationManager: ObservableObject {
    
    @Published var currentRegion = MKCoordinateRegion(center: CLLocation(latitude: 48.864716, longitude: 2.349014).coordinate, latitudinalMeters: CLLocationDistance(10000), longitudinalMeters: CLLocationDistance(10000))
    
    let userLocationManager = CLLocationManager()
    
    let authorizationStatus = CLLocationManager.authorizationStatus()
    
    func requestPermission() {
        if authorizationStatus == .notDetermined {
            userLocationManager.requestAlwaysAuthorization()
        }
    }
    
    init() {
        requestPermission()
        
        guard let userLocation = userLocationManager.location?.coordinate else {return}
        
        currentRegion = MKCoordinateRegion(center: userLocation, latitudinalMeters: CLLocationDistance(1000), longitudinalMeters: CLLocationDistance(1000))
    }
    
    func goToUserLocation() {
        guard let userLocation = userLocationManager.location?.coordinate else {return}
        currentRegion = MKCoordinateRegion(center: userLocation, latitudinalMeters: CLLocationDistance(1000), longitudinalMeters: CLLocationDistance(1000))
    }
    
}
