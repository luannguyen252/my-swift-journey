//
//  City_ExplorerApp.swift
//  Shared
//
//  Created by Andreas Schultz on 08.09.20.
//

import SwiftUI

@main
struct City_ExplorerApp: App {
    
    @StateObject var locationManager = LocationManager()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(locationManager)
        }
    }
}
