//
//  DownloadedImage.swift
//  City Explorer
//
//  Created by Andreas Schultz on 11.09.20.
//

import SwiftUI

struct DownloadedImage: Identifiable {
    let id = UUID()
    let image: UIImage
}

