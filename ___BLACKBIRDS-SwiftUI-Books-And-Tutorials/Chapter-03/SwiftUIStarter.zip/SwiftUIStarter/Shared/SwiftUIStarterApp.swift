//File: SwiftUIStarterApp.swift
//Project: SwiftUIStarter
//Created on 09.08.20
//Visit www.BLCKBIRDS.com for more tutorials.

import SwiftUI

@main
struct SwiftUIStarterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
