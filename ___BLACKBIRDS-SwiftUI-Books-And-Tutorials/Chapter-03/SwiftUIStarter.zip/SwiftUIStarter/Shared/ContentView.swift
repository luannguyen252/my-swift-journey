//File: ContentView.swift
//Project: SwiftUIStarter
//Created on 09.08.20
//Visit www.BLCKBIRDS.com for more tutorials.

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("My first SwiftUI app")
                .foregroundColor(.purple)
                .padding()
                .font(.largeTitle)
            HStack {
                Text("That's awesome")
                Spacer()
                Text("Yeah")
            }
                .padding()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
