//File: RollTheDice_App.swift
//Project: RollTheDice!
//Created on 13.08.20
//Visit www.BLCKBIRDS.com for more tutorials.

import SwiftUI

@main
struct RollTheDice_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
