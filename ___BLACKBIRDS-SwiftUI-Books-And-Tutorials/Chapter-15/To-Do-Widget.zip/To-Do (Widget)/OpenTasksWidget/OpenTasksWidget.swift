//
//  OpenTasksWidget.swift
//  OpenTasksWidget
//
//  Created by Andreas Schultz on 04.01.21.
//

import WidgetKit
import SwiftUI
import CoreData

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> SimpleEntry {
        SimpleEntry(date: Date(), toDoItems: [ToDoItem()])
    }

    func getSnapshot(in context: Context, completion: @escaping (SimpleEntry) -> ()) {
        
        let viewContext = PersistenceController.shared.container.viewContext
        let request = NSFetchRequest<ToDoItem>(entityName: "ToDoItem")
        //Filter out tasks marked as done
        request.predicate = NSPredicate(format: "taskDone = %d")
        
        do {
            let fetchedItems = try viewContext.fetch(request)
            let entry = SimpleEntry(date: Date(), toDoItems: fetchedItems)
            completion(entry)
        } catch {
            fatalError("Failed to fetch tasks: \(error)")
        }
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<Entry>) -> ()) {
    
        let viewContext = PersistenceController.shared.container.viewContext
        let request = NSFetchRequest<ToDoItem>(entityName: "ToDoItem")
        request.predicate = NSPredicate(format: "taskDone = %d")
        
        do {
            let fetchedItems = try viewContext.fetch(request)
            print(fetchedItems)
            var entries: [SimpleEntry] = []
            entries.append(SimpleEntry(date: Date(), toDoItems: fetchedItems))
            let timeline = Timeline(entries: entries, policy: .never)
            completion(timeline)
        } catch {
            fatalError("Failed to fetch tasks: \(error)")
        }
    }
    
}

struct SimpleEntry: TimelineEntry {
    let date: Date
    let toDoItems: [ToDoItem]
}

struct OpenTasksWidgetEntryView : View {
    
    @Environment(\.widgetFamily) var family
    
    var entry: Provider.Entry

    var body: some View {
        switch family {
        case .systemLarge:
            VStack(alignment: .leading) {
                Text("\(entry.toDoItems.count) open tasks")
                    .foregroundColor(.blue)
                    .font(.title)
                Divider()
                ForEach(entry.toDoItems.prefix(7), id: \.self) { item in
                    Text(item.taskTitle ?? "")
                        .padding(.top, 3)
                        .lineLimit(1)
                }
                if entry.toDoItems.count > 7 {
                    Text("More ...")
                        .padding(.top, 3)
                        .foregroundColor(.blue)
                }
                Spacer()
            }
                .padding()
        case .systemMedium:
            HStack {
                VStack(alignment: .leading) {
                    Text("\(entry.toDoItems.count)")
                    Text("open")
                    Text("tasks")
                }
                    .font(.title)
                    .foregroundColor(.blue)
                Divider()
                VStack(alignment: .leading) {
                    ForEach(entry.toDoItems.prefix(3), id: \.self) { item in
                        Text(item.taskTitle ?? "")
                            .padding(.top, 3)
                            .lineLimit(1)
                    }
                    if entry.toDoItems.count > 3 {
                        Text("More ...")
                            .padding(.top, 3)
                            .foregroundColor(.blue)
                    }
                    Spacer()
                }
                Spacer()
            }
                .padding()
        case .systemSmall:
            VStack(alignment: .leading) {
                Text("\(entry.toDoItems.count) open tasks")
                    .foregroundColor(.blue)
                    .font(.headline)
                    .padding(.top, 2)
                Divider()
                ForEach(entry.toDoItems.prefix(3), id: \.self) { item in
                    Text(item.taskTitle ?? "")
                        .font(.caption)
                        .padding(.bottom, 2)
                        .lineLimit(1)
                }
                if entry.toDoItems.count > 3 {
                    Text("More ...")
                        .font(.caption)
                        .padding(.top, 2)
                        .foregroundColor(.blue)
                }
                Spacer()
            }
                .padding()
        }
    }
}

@main
struct OpenTasksWidget: Widget {
    
    
    let kind: String = "OpenTasksWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            OpenTasksWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("My Widget")
        .description("This is an example widget.")
    }
}

struct OpenTasksWidget_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            OpenTasksWidgetEntryView(entry: SimpleEntry(date: Date(), toDoItems: [ToDoItem]()))
                .previewContext(WidgetPreviewContext(family: .systemSmall))
            OpenTasksWidgetEntryView(entry: SimpleEntry(date: Date(), toDoItems: [ToDoItem]()))
                .previewContext(WidgetPreviewContext(family: .systemMedium))
            OpenTasksWidgetEntryView(entry: SimpleEntry(date: Date(), toDoItems: [ToDoItem]()))
                .previewContext(WidgetPreviewContext(family: .systemLarge))
        }
    }
}
