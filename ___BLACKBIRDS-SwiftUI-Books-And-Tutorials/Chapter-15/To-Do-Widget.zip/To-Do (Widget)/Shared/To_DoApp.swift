//
//  To_DoApp.swift
//  Shared
//
//  Created by Andreas Schultz on 04.09.20.
//

import SwiftUI

@main
struct To_DoApp: App {
    
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            TasksView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
