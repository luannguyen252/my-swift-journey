//
//  MyDemoAppApp.swift
//  MyDemoApp
//
//  Created by Andreas Schultz on 31.12.20.
//

import SwiftUI

@main
struct MyDemoAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
