//
//  MyWidgetDownloadManager.swift
//  StockX
//
//  Created by Andreas Schultz on 01.01.21.
//

import Foundation

class WidgetDownloadManager {
    
    func downloadJSON(stockSymbol: String, handler: @escaping ([DataEntry]) -> Void) {
        
        var dataEntries = [DataEntry]()
        
        if let url = URL(string: generateRequestURL(stockSymbol: stockSymbol)) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let data = data {
                    let jsonDecoder = JSONDecoder()
                    do {
                        let parsedJSON = try jsonDecoder.decode(TimeSeriesJSON.self, from: data)
                        for timeSeries in parsedJSON.timeSeries {
                            dataEntries.append(DataEntry(date: Date(timeSeries.key, dateFormat: "yyyy-MM-dd HH:mm:ss"), close: (timeSeries.value.close as NSString).doubleValue))
                        }
                        if dataEntries.count == parsedJSON.timeSeries.count {
                            dataEntries.sort(by: {$0.date.compare($1.date) == .orderedAscending})
                            handler(self.filterDataEntries(dataEntries: dataEntries))
                        }
                    } catch {
                        print(error)
                    }
                }
            }.resume()
        }
    }
    
    private func filterDataEntries(dataEntries: [DataEntry]) -> [DataEntry] {
        
        guard let lastDateOfData = dataEntries.last?.date else { return [DataEntry]() }
        
        var dailyEntries = [DataEntry]()
        
        for entry in dataEntries {
            if Calendar.current.isDate(entry.date, equalTo: lastDateOfData, toGranularity: .day) {
                dailyEntries.append(entry)
            }
        }
        
        return dailyEntries
        
    }
    
}
