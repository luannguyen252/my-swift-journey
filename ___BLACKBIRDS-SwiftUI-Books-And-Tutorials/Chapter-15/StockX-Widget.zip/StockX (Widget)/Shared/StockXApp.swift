//
//  StockXApp.swift
//  Shared
//
//  Created by Andreas Schultz on 12.09.20.
//

import SwiftUI

@main
struct StockXApp: App {
    var body: some Scene {
        WindowGroup {
            StockList()
        }
    }
}
