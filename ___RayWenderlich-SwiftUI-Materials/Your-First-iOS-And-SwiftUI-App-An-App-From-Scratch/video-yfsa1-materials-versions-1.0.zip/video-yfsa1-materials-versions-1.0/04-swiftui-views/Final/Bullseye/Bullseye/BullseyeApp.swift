//
//  BullseyeApp.swift
//  Bullseye
//
//  Created by Ray Wenderlich on 10/16/20.
//

import SwiftUI

@main
struct BullseyeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
