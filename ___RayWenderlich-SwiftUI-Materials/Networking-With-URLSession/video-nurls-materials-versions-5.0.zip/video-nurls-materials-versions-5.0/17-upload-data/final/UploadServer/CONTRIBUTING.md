# Contributing to Vapor API Template

If you found a mistake or think of a cool new feature, please [create an issue](https://github.com/vapor/api-template/issues/new) or, if you want to implement it yourself, [fork this repo](https://github.com/vapor/api-template/fork) and open a Pull Request!

We'll take a look as soon as we can.

Thanks!

## Maintainers

- [@0xTim](https://github.com/0xTim)

See the [Vapor maintainers doc](https://github.com/vapor/vapor/blob/master/Docs/maintainers.md) for more information.
