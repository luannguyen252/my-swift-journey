/// Copyright (c) 2019 Razeware LLC
/// 
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
/// 
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
/// 
/// Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
/// distribute, sublicense, create a derivative work, and/or sell copies of the
/// Software in any work that is designed, intended, or marketed for pedagogical or
/// instructional purposes related to programming, coding, application development,
/// or information technology.  Permission for such use, copying, modification,
/// merger, publication, distribution, sublicensing, creation of derivative works,
/// or sale is expressly withheld.
/// 
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.

import SwiftUI

struct EmployeeImageView : View {
    
    var angle:Angle = Angle(degrees: 365.0)
    var yVal:Double = 370
    var xVal:Double = 200
    let angularGradient = AngularGradient(gradient: Gradient(colors: [.red, .orange, .yellow, .green]), center: .center, angle: .degrees(0))
    
    
    var body: some View {
        
//        Circle().stroke(angularGradient, lineWidth: 30).padding()
        
        VStack {
            Path { path in

                path.addArc(center: CGPoint(x: xVal, y: yVal), radius: 50.0, startAngle: Angle(degrees: 0), endAngle: self.angle, clockwise: false)

                path.addLine(to: CGPoint(x: xVal + 20*cos(self.angle.radians), y: yVal+20*sin(self.angle.radians)))

                path.addArc(center: CGPoint(x: xVal, y: yVal), radius: 70.0, startAngle: self.angle, endAngle: Angle(degrees: 0), clockwise: true)

                path.closeSubpath()

            }.fill(angularGradient)
        }
    }
}

struct EmployeeImageShapeView : Shape {
    
    var angle:Angle = Angle(degrees: 365.0)
    var yVal:Double = 370
    var xVal:Double = 200
    
    func path(in rect: CGRect) -> Path {
        
        var path = Path()
        path.addArc(center: CGPoint(x: xVal, y: yVal), radius: 50.0, startAngle: Angle(degrees: 0), endAngle: angle, clockwise: false)
        
        path.addLine(to: CGPoint(x: xVal + 20*cos(angle.radians), y: yVal+20*sin(angle.radians)))
        
        path.addArc(center: CGPoint(x: xVal, y: yVal), radius: 70.0, startAngle: angle, endAngle: Angle(degrees: 0), clockwise: true)
        
        path.closeSubpath()
        
        return path
        
    }

}

#if DEBUG
struct EmployeeImageView_Previews : PreviewProvider {
    
    static var previews: some View {
        
        Group {
            
            EmployeeImageView()
        
            EmployeeImageShapeView().fill(AngularGradient(gradient: Gradient(colors: [.red, .orange, .yellow, .green]), center: .center, angle: .degrees(0)))
        }
    }
}
#endif
