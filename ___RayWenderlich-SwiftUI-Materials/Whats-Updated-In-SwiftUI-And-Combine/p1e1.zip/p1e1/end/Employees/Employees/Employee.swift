//
//  Employee.swift
//  Employees
//
//  Created by Josh Steele on 6/9/19.
//  Copyright © 2019 Josh Steele. All rights reserved.
//

import SwiftUI
import Combine

struct Employee {
    
    var id = UUID()
    var name: String
    var title: String
    
}

class WenderlichEmployee: ObservableObject, Identifiable {
    
    let id = UUID()
    var employee: Employee
    var employeeActive: Bool = true {
        didSet {
            didChange.send(self)
        }
    }
    
    var didChange = PassthroughSubject<WenderlichEmployee, Never>()
    
    init(employee: Employee) {
        self.employee = employee
        self.employeeActive = true
    }
}

#if DEBUG
let testData: [Employee] = [Employee(name: "Ray Wenderlich", title: "Owner"),
                            Employee(name: "Victoria Wenderlich", title: "Digital Artist"),
                            Employee(name: "Andrea Lepley", title: "Video Team Lead"),
                            Employee(name: "Sam Davies", title: "CTO"),
                            Employee(name: "Katie Collins", title: "Customer Support Lead"),
                            Employee(name: "Tiffani Randolph", title: "Marketing Associate")]

let testData2: [WenderlichEmployee] = [WenderlichEmployee(employee: Employee(name: "Ray Wenderlich", title: "Owner")),
                                       WenderlichEmployee(employee: Employee(name: "Victoria Wenderlich", title: "Digital Artist")),
                                       WenderlichEmployee(employee: Employee(name: "Andrea Lepley", title: "Video Team Lead")),
                                       WenderlichEmployee(employee: Employee(name: "Sam Davies", title: "CTO")),
                                       WenderlichEmployee(employee: Employee(name: "Katie Collins", title: "Customer Support Lead")),
                                       WenderlichEmployee(employee: Employee(name: "Tiffani Randolph", title: "Marketing Associate"))]


#endif
