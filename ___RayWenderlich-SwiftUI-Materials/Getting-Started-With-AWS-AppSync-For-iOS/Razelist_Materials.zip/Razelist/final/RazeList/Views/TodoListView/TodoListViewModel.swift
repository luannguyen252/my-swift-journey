/// Copyright (c) 2020 Razeware LLC
///
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
///
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
///
/// Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
/// distribute, sublicense, create a derivative work, and/or sell copies of the
/// Software in any work that is designed, intended, or marketed for pedagogical or
/// instructional purposes related to programming, coding, application development,
/// or information technology.  Permission for such use, copying, modification,
/// merger, publication, distribution, sublicensing, creation of derivative works,
/// or sale is expressly withheld.
///
/// This project and source code may use libraries or frameworks that are
/// released under various Open-Source licenses. Use of those libraries and
/// frameworks are governed by their own individual licenses.
///
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.

import Foundation
import Amplify

class TodoListViewModel: ObservableObject {
  @Published var todos: [Todo] = []
  @Published var completedTodos: [Todo] = []

  func createTodo(name: String, description: String?) {
    let item = Todo(name: name, description: description, completed: false)
    todos.append(item)

    Amplify.DataStore.save(item) { result in
      switch result {
      case .success(let savedItem):
        print("Saved item: \(savedItem.name)")
      case .failure(let error):
        print("Could not save item with error: \(error)")
      }
    }
  }

  func deleteItems(at offsets: IndexSet, from todoList: inout [Todo]) {
    for index in offsets {
      let todo = todoList[index]
      delete(todo: todo)
    }

    todoList.remove(atOffsets: offsets)
  }

  func deleteTodos(at offsets: IndexSet) {
    deleteItems(at: offsets, from: &todos)
  }

  func deleteCompletedTodos(at offsets: IndexSet) {
    deleteItems(at: offsets, from: &completedTodos)
  }

  func saveTodoItem(name: String, description: String?) {}

  func loadToDos() {
    Amplify.DataStore.query(Todo.self) { result in
      switch result {
      case .success(let todos):
        self.todos = todos.filter { !$0.completed }
        completedTodos = todos.filter { $0.completed }
      case .failure(let error):
        print("Could not query DataStore: \(error)")
      }
    }
  }

  func toggleComplete(_ todo: Todo) {
    var updatedTodo = todo
    updatedTodo.completed.toggle()

    Amplify.DataStore.save(updatedTodo) { result in
      switch result {
      case .success(let savedTodo):
        print("Updated item: \(savedTodo.name )")
      case .failure(let error):
        print("Could not update data with error: \(error)")
      }
    }

    if updatedTodo.completed {
      if let index = todos.firstIndex(where: { $0.id == todo.id }) {
        todos.remove(at: index)
        completedTodos.insert(updatedTodo, at: 0)
      }
    } else {
      if let index = completedTodos.firstIndex(where: { $0.id == todo.id }) {
        completedTodos.remove(at: index)
        todos.insert(updatedTodo, at: 0)
      }
    }
  }

  func delete(todo: Todo) {
    Amplify.DataStore.delete(todo) { result in
      switch result {
      case .success:
        print("Deleted item: \(todo.name)")
      case .failure(let error):
        print("Could not update data with error: \(error)")
      }
    }
  }
}
