/// Copyright (c) 2019 Razeware LLC
///
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
///
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
///
/// Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
/// distribute, sublicense, create a derivative work, and/or sell copies of the
/// Software in any work that is designed, intended, or marketed for pedagogical or
/// instructional purposes related to programming, coding, application development,
/// or information technology.  Permission for such use, copying, modification,
/// merger, publication, distribution, sublicensing, creation of derivative works,
/// or sale is expressly withheld.
///
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.

import SwiftUI

struct ColorPicker: View {
  @Binding var contrast: ContrastModel
  
  var body: some View {
    VStack {
      ZStack {
        contrast.bkgd.colorView
        Text(verbatim: contrast.ratio())
          .accessibility(label: Text("Contrast ratio: " + contrast.ratio() + "."))
          .font(.largeTitle)
          .foregroundColor(contrast.text.colorView)
      }
      .accessibility(addTraits: .isHeader)
      HStack {
        VStack {
          Text("Text")
            .accessibility(addTraits: .isHeader)
            .padding(.bottom)
          SliderBlock(colorValue: $contrast.text.r, colorInt: contrast.text.rInt, colorString: "Red",
            contrast: $contrast, bkgdOrText: "Text")
          SliderBlock( colorValue: $contrast.text.g, colorInt: contrast.text.gInt, colorString: "Green",
            contrast: $contrast, bkgdOrText: "Text")
          SliderBlock(colorValue: $contrast.text.b, colorInt: contrast.text.bInt, colorString: "Blue",
            contrast: $contrast, bkgdOrText: "Text")
        }
        .padding()
        VStack {
          Text("Background")
            .accessibility(addTraits: .isHeader)
            .padding(.bottom)
          SliderBlock(colorValue: $contrast.bkgd.r, colorInt: contrast.bkgd.rInt, colorString: "Red",
            contrast: $contrast, bkgdOrText: "Background")
          SliderBlock(colorValue: $contrast.bkgd.g, colorInt: contrast.bkgd.gInt, colorString: "Green",
            contrast: $contrast, bkgdOrText: "Background")
          SliderBlock(colorValue: $contrast.bkgd.b, colorInt: contrast.bkgd.bInt, colorString: "Blue",
            contrast: $contrast, bkgdOrText: "Background")
        }
        .padding()
      }
      .padding()
    }
  }
}

struct ColorPicker_Previews: PreviewProvider {
  static var previews: some View {
    ColorPicker(contrast: .constant(ContrastViewModel(
      count: 1).contrasts[0]))
  }
}

struct SliderBlock: View {
  @Binding var colorValue: Double
  var colorInt: String
  let colorString: String
  @Binding var contrast: ContrastModel
  let bkgdOrText: String

  var body: some View {
    VStack {
      AdaptingStack {
        Text(self.colorString + ": ")
        Text(self.colorInt)
        .accessibility(identifier: "value")
      }
      .accessibility(hidden: true)
      .font(.caption)
      Slider(value: $colorValue)
        .accessibility(label: Text(bkgdOrText + " " + colorString))
        .accessibility(value: Text(colorInt + ". Ratio " + contrast.ratio()))
    }
  }
}
