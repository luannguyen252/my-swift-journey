# ExpandableListSwiftUI
Step-by-step tutorial on how to expand and collapse list rows with animation in SwiftUI. Read [my article on the subject to learn more](https://www.vadimbulavin.com/expand-and-collapse-list-with-animation-in-swiftui/).
