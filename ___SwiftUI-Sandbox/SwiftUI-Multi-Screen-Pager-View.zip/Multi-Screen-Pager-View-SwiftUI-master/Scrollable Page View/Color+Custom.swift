// Kevin Li - 12:37 PM - 6/6/20

import SwiftUI

extension Color {

    static let blackPearl = Color("blackPearl")
    static let blackPearlComplement = Color("blackPearlComplement")

}
