# Multi-Screen-Pager-View-SwiftUI - WIP

This project is a demonstration of how to create a multi screen pager view in SwiftUI, maintaining swift animations and clean code in the process. In the project, I put a lot of comments explaining the code behind this. It's by no means perfect and it is my hope that others in the community can perfect the animations I've laid out.

## Contributing
- If you find a bug, or would like to suggest a new feature or enhancement, feel free to [file an issue](https://github.com/ThasianX/Multi-Screen-Pager-View-SwiftUI/issues/new).

## Resources
- [Paging discussion](https://stackoverflow.com/questions/57028165/swiftui-scrollview-how-to-modify-content-offset-aka-paging)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details


