// Kevin Li - 7:07 PM - 7/3/20

import SwiftUI

struct ContentView: View {
    var body: some View {
        ListView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
