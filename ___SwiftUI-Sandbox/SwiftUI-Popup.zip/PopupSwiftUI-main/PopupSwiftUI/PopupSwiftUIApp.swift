//
//  PopupSwiftUIApp.swift
//  PopupSwiftUI
//
//  Created by Vadim Bulavin on 22.01.2021.
//

import SwiftUI

@main
struct PopupSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
