import XCTest

import SwiftUIFluxTests

var tests = [XCTestCaseEntry]()
tests += SwiftUIFluxTests.allTests()
XCTMain(tests)
