// Kevin Li - 5:05 PM - 7/31/20

import Foundation

protocol ColorSchemeObserver {

    func colorSchemeChanged()

}
