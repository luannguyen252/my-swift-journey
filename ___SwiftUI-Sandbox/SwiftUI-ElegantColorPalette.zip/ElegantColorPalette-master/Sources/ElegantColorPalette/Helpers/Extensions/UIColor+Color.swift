// Kevin Li - 11:38 PM - 7/27/20

import SwiftUI

extension UIColor {

    var asColor: Color {
        Color(self)
    }

}
