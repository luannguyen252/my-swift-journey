// Kevin Li - 6:06 PM - 6/13/20

import SwiftUI

struct VisitPreviewConstants {

    static let cellHeight: CGFloat = 30
    static let cellPadding: CGFloat = 10

    static let previewTime: TimeInterval = 3

}
