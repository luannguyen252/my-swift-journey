// Kevin Li - 2:46 PM - 6/1/20

import SwiftUI

extension Color {

    static let systemBackground = Color(UIColor.systemBackground)

}
