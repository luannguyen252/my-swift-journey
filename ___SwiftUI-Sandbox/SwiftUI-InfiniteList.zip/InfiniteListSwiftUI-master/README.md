## Article related to this project

- [Infinite List Scroll with SwiftUI and Combine](https://www.vadimbulavin.com/infinite-list-scroll-swiftui-combine/).

---

# InfiniteListSwiftUI

A sample project showcasing how to build an infinite list using the Combine and SwiftUI frameworks, and the MVVM iOS app architecture.

<p align="center">
  <img src="https://github.com/V8tr/InfiniteListSwiftUI/blob/master/demo.gif" alt="Infinite List Endless Scroll Paginated List in SwiftUI and Combine"/>
</p>
