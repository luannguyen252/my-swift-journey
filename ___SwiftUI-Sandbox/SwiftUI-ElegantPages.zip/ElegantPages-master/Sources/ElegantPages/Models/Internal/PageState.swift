// Kevin Li - 6:07 PM - 6/23/20

import Foundation

enum PageState: Equatable {

    case rearrange
    case scroll(animated: Bool)
    case completed

}
