// Kevin Li - 11:29 PM - 7/16/20

import UIKit

let screen = UIScreen.main.bounds
