// Kevin Li - 11:26 PM - 6/23/20

import SwiftUI

public extension View {

    var erased: AnyView {
        AnyView(self)
    }

}
