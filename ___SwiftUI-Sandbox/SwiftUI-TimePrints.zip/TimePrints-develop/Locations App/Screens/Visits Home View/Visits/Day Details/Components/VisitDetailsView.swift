import MapKit
import SwiftUI

struct VisitDetailsView: View {
    @Environment(\.appTheme) private var appTheme: UIColor

    @State private var isMapOpen = false
    @State private var isFavorite = false
    @State private var isEditingNotes = false

    @State private var notesInput = ""

    @Binding var selectedIndex: Int

    let index: Int
    let visit: Visit
    let setActiveVisitLocationAndDisplayMap: (Visit) -> Void

    private var isSelected: Bool {
        selectedIndex == index
    }

    var body: some View {
        visitDetailsView
            .animation(.spring())
            .padding(.top, isSelected ? 80 : 12)
            .padding(.horizontal, isSelected ? 0 : 40)
            .frame(height: VisitCellConstants.height(if: isSelected))
            .frame(maxWidth: VisitCellConstants.maxWidth(if: isSelected))
            .extendToScreenEdges()
            .background(appTheme.color)
            .clipShape(RoundedRectangle(cornerRadius: isSelected ? 30 : 10, style: .continuous))
            .animation(.easeInOut)
            .exitOnDrag(if: isSelected, onExit: resetViewState)
            .onTapGesture(perform: setSelectedVisitIndex)
            .onAppear(perform: setFavoritedStateAndNotesInput)
    }
}

private extension VisitDetailsView {
    private var visitDetailsView: some View {
        VStack(spacing: 2) {
            header
                .padding(.bottom, isSelected ? 10 : 0)
                .padding(.horizontal, isSelected ? 30 : 0)
            if !isMapOpen && !isEditingNotes {
                coreDetailsView
                    .transition(.scaleFade)
            }
            if isSelected {
                if !isEditingNotes {
                    interactableMapView
                        .transition(.scaleFade)
                }
                if !isMapOpen {
                    notesButton
                        .transition(.scaleFade)
                        .padding(.bottom, 100)
                }
            }
            Spacer()
        }
    }
}

private extension VisitDetailsView {
    private var header: some View {
        ZStack {
            HStack {
                if isSelected {
                    backButton
                        .transition(.scaleFade)
                }
                Spacer()
                favoriteButton
                    .id(visit.isFavorite)
            }
            locationNameText
                .id(isSelected)
                .padding(.horizontal, 30)
        }
        .transition(.scaleFade)
    }

    private var backButton: some View {
        BackButton(isMapOpen: isMapOpen, isEditingNotes: isEditingNotes, appTheme: appTheme.color, onBack: navigateBack)
    }

    private struct BackButton: View {
        let isMapOpen: Bool
        let isEditingNotes: Bool

        let appTheme: Color
        let onBack: () -> Void

        var body: some View {
            ZStack {
                whiteCircle
                    .scaleFade(if: !isMapOpen)
                BImage(perform: onBack, image: backButtonImage)
                    .foregroundColor(isMapOpen ? appTheme : .white)
            }
        }

        private var whiteCircle: some View {
            Color(.white)
                .frame(width: 30, height: 30)
                .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
        }

        private var backButtonImage: Image {
            Image(systemName: !isEditingNotes ? "arrow.left" : "xmark.circle.fill")
        }
    }

    private func navigateBack() {
        if isMapOpen {
            minimizeMap()
        } else if isEditingNotes {
            resetNoteState()
        } else {
            unselectRow()
        }
    }

    private func minimizeMap() {
        isMapOpen = false
    }

    private func resetNoteState() {
        isEditingNotes = false
        UIApplication.shared.endEditing(true)
        commitNoteEdits()
    }

    private func unselectRow() {
        selectedIndex = -1
    }

    private var locationNameText: some View {
        Text(visit.location.name)
            .font(isSelected ? .system(size: 22) : .headline)
            .fontWeight(isSelected ? .bold : .regular)
            .lineLimit(isSelected ? nil : 1)
            .multilineTextAlignment(.center)
    }

    private var favoriteButton: FavoriteButton {
        FavoriteButton(visit: visit)
    }
}

private extension VisitDetailsView {
    private var coreDetailsView: some View {
        Group {
            visitDurationText
                .id(isSelected)
            if isSelected {
                fullMonthWithDayOfWeekText
                    .padding(.top, 8)
                    .padding(.bottom, 10)
            }
            locationTagView
                .padding(.top, 6)
                .padding(.bottom, isSelected ? 20 : 4)
        }
    }

    private var visitDurationText: some View {
        Text(visit.duration)
            .font(isSelected ? .system(size: 18) : .system(size: 10))
            .tracking(isSelected ? 2 : 0)
    }

    private var fullMonthWithDayOfWeekText: some View {
        Text(visit.arrivalDate.fullMonthWithDayOfWeek.uppercased())
            .font(.caption)
    }

    private var locationTagView: some View {
        TagView(tag: visit.location.tag, displayName: isSelected)
    }
}

private extension VisitDetailsView {
    private var interactableMapView: some View {
        Group {
            staticMapView
                .padding(.bottom, 10)
            VStack(spacing: 16) {
                locationAddressText
                if isMapOpen {
                    mapOptionsView
                }
            }
            .padding(.horizontal, 80)
            .padding(.bottom, 10)
        }
    }

    private var staticMapView: some View {
        StaticMapView(
            coordinate: visit.location.coordinate,
            name: visit.location.name,
            userLocationColor: appTheme,
            annotationColor: visit.location.accent)
            .frame(width: isMapOpen ? screen.width : screen.width / 2.5,
                   height: isMapOpen ? screen.height * 8 / 15 : screen.width / 2.5)
            .cornerRadius(isMapOpen ? 0 : screen.width / 5)
            .onTapGesture(perform: toggleMapState)
            .animation(.spring())
    }

    private func toggleMapState() {
        isMapOpen.toggle()
    }

    private var locationAddressText: some View {
        Text(visit.location.address.uppercased())
            .font(.headline)
            .lineLimit(nil)
            .multilineTextAlignment(.center)
    }

    private var mapOptionsView: some View {
        MapOptionsView(focusLocationOnAnnotatedMap: focusLocationOnAnnotatedMap, coordinate: visit.location.coordinate)
    }

    private func focusLocationOnAnnotatedMap() {
        setActiveVisitLocationAndDisplayMap(visit)
    }

    private struct MapOptionsView: View {
        let focusLocationOnAnnotatedMap: () -> Void
        let coordinate: CLLocationCoordinate2D

        var body: some View {
            HStack(spacing: 20) {
                focusLocationOnAnnotatedMapButton
                openAppleMapsButton
            }
        }

        private var focusLocationOnAnnotatedMapButton: some View {
            Button(action: focusLocationOnAnnotatedMap) {
                Image(systemName: "magnifyingglass")
                    .resizable()
                    .frame(width: 35, height: 35)
            }
            .buttonStyle(PlainButtonStyle())
        }

        private var openAppleMapsButton: some View {
            Button(action: openAppleMaps) {
                Image(systemName: "arrow.up.right.diamond")
                    .resizable()
                    .frame(width: 35, height: 35)
            }
            .buttonStyle(PlainButtonStyle())
        }

        private func openAppleMaps() {
            let mapItem = MKMapItem(placemark: MKPlacemark(coordinate: coordinate, addressDictionary:nil))
            mapItem.name = "Visit Location"
            mapItem.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey : MKLaunchOptionsDirectionsModeDriving])
        }
    }
}

private extension VisitDetailsView {
    private var notesButton: some View {
        NotesButton(isEditingNotes: $isEditingNotes, notesInput: $notesInput, onCommit: commitNoteEdits)
    }

    private struct NotesButton: View {
        @Binding var isEditingNotes: Bool
        @Binding var notesInput: String

        let onCommit: () -> Void

        var horizontalPadding: CGFloat = 50

        var body: some View {
            Button(action: displayEditNotesView) {
                VStack(spacing: 2) {
                    dividerView
                        .padding(.bottom, 20)
                    notesHeaderText
                    notesContainer
                    dividerView
                        .padding(.top, 20)
                }
            }
            .buttonStyle(PlainButtonStyle())
        }

        private func displayEditNotesView() {
            isEditingNotes = true
        }

        private var dividerView: some View {
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.black)
                .frame(width: isEditingNotes ? screen.width - horizontalPadding*2 : screen.width/10, height: 3)
        }

        private var notesHeaderText: some View {
            Text("NOTES")
                .font(.system(size: 22))
                .fontWeight(.bold)
                .tracking(2)
        }

        private var notesContainer: some View {
            Group {
                if isEditingNotes {
                    notesTextView
                        .frame(width: screen.width - horizontalPadding*2)
                } else {
                    visitNotesTextViewWithDefaultTextIfEmpty
                        .padding(.leading, 40)
                        .padding(.trailing, 40)
                }
            }
        }

        private var visitNotesTextViewWithDefaultTextIfEmpty: some View {
            Group {
                if !notesInput.isEmpty {
                    visitNotesTextView
                } else {
                    emptyNotesText
                }
            }
        }

        private var notesTextView: some View {
            AutoResizingTextField(text: $notesInput, isActive: isEditingNotes)
        }

        private var visitNotesTextView: some View {
            GeometryReader { geometry in
                ScrollView(.vertical, showsIndicators: true) {
                    Text(self.notesInput)
                        .fixedSize(horizontal: false, vertical: true)
                        .lineLimit(nil)
                        .multilineTextAlignment(.center)
                        .frame(width: geometry.size.width)
                }
            }
        }

        private var emptyNotesText: some View {
            Text("TAP TO ADD")
                .font(.caption)
        }
    }

    private func commitNoteEdits() {
        visit.setNotes(notesInput)
        updateNotesInput()
    }
}

private extension VisitDetailsView {
    private func setSelectedVisitIndex() {
        selectedIndex = index
    }

    private func resetViewState() {
        resetNoteState()
        minimizeMap()
        unselectRow()
    }

    private func setFavoritedStateAndNotesInput() {
        setFavoriteState()
        updateNotesInput()
    }

    private func setFavoriteState() {
        isFavorite = visit.isFavorite
    }

    private func updateNotesInput() {
        notesInput = visit.notes
    }
}

struct VisitDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            VisitDetailsView(selectedIndex: .constant(1), index: -1, visit: .preview, setActiveVisitLocationAndDisplayMap: { _ in }).previewLayout(.sizeThatFits)
            
            VisitDetailsView(selectedIndex: .constant(1), index: 1,  visit: .preview, setActiveVisitLocationAndDisplayMap: { _ in })
        }
        .environment(\.appTheme, .violetGum)
    }
}
