// Kevin Li - 9:08 PM - 2/19/20

import Foundation
import UIKit

extension UIImage {
    static let tagFill = UIImage(named: "tag.fill")!
    
    static let infoCircleFill = UIImage(named: "info.circle.fill")!
}
