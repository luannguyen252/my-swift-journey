import SwiftUI
import UIKit

extension UIColor {
    var color: Color {
        Color(self)
    }
}
