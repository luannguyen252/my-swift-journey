# WIP: TimePrints
Automated time and location tracking. View your timeprints with a sublime user interface and fluid animations. Perfectly SwiftUI.
