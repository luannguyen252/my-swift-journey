import XCTest

import DoritosColorsTests

var tests = [XCTestCaseEntry]()
tests += DoritosColorsTests.allTests()
XCTMain(tests)
