# DoritosColors-SwiftUI

A simple extension to SwiftUI's Color library to make it a bit tastier...

## Usage

```swift
Color.Doritos.nachoCheese
Color.Doritos.coolRanch
Color.Doritos.flaminHotNacho
```

## Disclaimer

I am in no way affiliated with Doritos, which is a registered trademark of Frito-Lay North America, Inc. a Division of PepsiCo. These colors are not the actual represented branding of each Doritos product presented. This package is provided for personal use only.
