import XCTest

import CoreTests

var tests = [XCTestCaseEntry]()
tests += CoreTests.allTests()
XCTMain(tests)
