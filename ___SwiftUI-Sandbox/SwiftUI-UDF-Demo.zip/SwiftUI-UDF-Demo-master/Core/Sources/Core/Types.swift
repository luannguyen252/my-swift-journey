//
//  File.swift
//  
//
//  Created by Alexey Demedetskii on 5/31/20.
//

import Foundation

public typealias UUID = Foundation.UUID
