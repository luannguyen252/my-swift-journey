import XCTest

import NetworkOperatorTests

var tests = [XCTestCaseEntry]()
tests += NetworkOperatorTests.allTests()
XCTMain(tests)
