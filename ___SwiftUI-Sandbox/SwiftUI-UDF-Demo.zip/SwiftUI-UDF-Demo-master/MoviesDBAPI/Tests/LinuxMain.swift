import XCTest

import MoviesDBAPITests

var tests = [XCTestCaseEntry]()
tests += MoviesDBAPITests.allTests()
XCTMain(tests)
