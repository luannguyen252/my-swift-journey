# MixingSwiftUIAndUIKit
The app demonstrates how to use `UIView` and `UIViewController` in SwiftUI. It complements my article [Using UIView and UIViewController in SwiftUI](https://www.vadimbulavin.com/using-uikit-uiviewcontroller-and-uiview-in-swiftui/).
